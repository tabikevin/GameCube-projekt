DROP DATABASE IF EXISTS gamecube;
CREATE DATABASE gamecube CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gamecube;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    role ENUM('user', 'admin') DEFAULT 'user',
    is_active TINYINT(1) DEFAULT 1,
    failed_login_attempts INT DEFAULT 0,
    locked_until TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login_at TIMESTAMP NULL,
    INDEX idx_username (username),
    INDEX idx_email (email),
    INDEX idx_role (role),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    short_description TEXT,
    long_description TEXT,
    platform ENUM('pc', 'ps', 'xbox', 'switch') NOT NULL,
    tag ENUM('top', 'new', 'sale', 'normal') DEFAULT 'normal',
    price INT NOT NULL,
    original_price INT NULL,
    discount_percent INT DEFAULT 0,
    image_url VARCHAR(255),
    is_active TINYINT(1) DEFAULT 1,
    view_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_platform (platform),
    INDEX idx_tag (tag),
    INDEX idx_active (is_active),
    INDEX idx_price (price),
    INDEX idx_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE game_keys (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    key_code VARCHAR(255) NOT NULL UNIQUE,
    is_sold TINYINT(1) DEFAULT 0,
    sold_to_user_id INT NULL,
    sold_at TIMESTAMP NULL,
    order_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_product_id (product_id),
    INDEX idx_is_sold (is_sold),
    INDEX idx_sold_to_user (sold_to_user_id),
    INDEX idx_order_id (order_id),
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (sold_to_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    order_number VARCHAR(20) UNIQUE,
    total_price INT NOT NULL,
    status ENUM('pending', 'paid', 'cancelled', 'refunded') DEFAULT 'pending',
    payment_method ENUM('online_card', 'bank_transfer', 'paypal') NOT NULL,
    payment_transaction_id VARCHAR(100) NULL,
    billing_name VARCHAR(100) NOT NULL,
    billing_address VARCHAR(255) NOT NULL,
    billing_city VARCHAR(100) NOT NULL,
    billing_zip VARCHAR(20) NOT NULL,
    billing_country VARCHAR(100) NOT NULL,
    billing_tax_number VARCHAR(50),
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    paid_at TIMESTAMP NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at),
    INDEX idx_order_number (order_number),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    unit_price INT NOT NULL,
    total_price INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_order_id (order_id),
    INDEX idx_product_id (product_id),
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE audit_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    table_name VARCHAR(50) NOT NULL,
    record_id INT NOT NULL,
    action ENUM('INSERT', 'UPDATE', 'DELETE') NOT NULL,
    old_values JSON NULL,
    new_values JSON NULL,
    user_id INT NULL,
    ip_address VARCHAR(45) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_table_name (table_name),
    INDEX idx_record_id (record_id),
    INDEX idx_action (action),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    session_id VARCHAR(100) NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_session_id (session_id),
    INDEX idx_product_id (product_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE favorites (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_favorite (user_id, product_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE coupons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    discount_type ENUM('percent', 'fixed') NOT NULL,
    discount_value INT NOT NULL,
    min_order_value INT DEFAULT 0,
    max_uses INT NULL,
    used_count INT DEFAULT 0,
    valid_from TIMESTAMP NOT NULL,
    valid_until TIMESTAMP NOT NULL,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_code (code),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE OR REPLACE VIEW v_active_products AS
SELECT 
    p.id,
    p.name,
    p.short_description,
    p.platform,
    p.tag,
    p.price,
    p.original_price,
    p.discount_percent,
    p.image_url,
    p.view_count,
    COUNT(gk.id) as available_keys,
    CASE WHEN COUNT(gk.id) > 0 THEN 1 ELSE 0 END as in_stock
FROM products p
LEFT JOIN game_keys gk ON gk.product_id = p.id AND gk.is_sold = 0
WHERE p.is_active = 1
GROUP BY p.id;

CREATE OR REPLACE VIEW v_user_orders AS
SELECT 
    o.id as order_id,
    o.order_number,
    o.user_id,
    u.username,
    u.email,
    o.total_price,
    o.status,
    o.payment_method,
    o.created_at,
    o.paid_at,
    COUNT(oi.id) as item_count,
    SUM(oi.quantity) as total_items
FROM orders o
JOIN users u ON u.id = o.user_id
LEFT JOIN order_items oi ON oi.order_id = o.id
GROUP BY o.id;

CREATE OR REPLACE VIEW v_admin_stats AS
SELECT 
    (SELECT COUNT(*) FROM users WHERE role = 'user') as total_users,
    (SELECT COUNT(*) FROM users WHERE role = 'user' AND is_active = 1) as active_users,
    (SELECT COUNT(*) FROM products WHERE is_active = 1) as total_products,
    (SELECT COUNT(*) FROM orders WHERE status = 'paid') as paid_orders,
    (SELECT COUNT(*) FROM orders WHERE status = 'pending') as pending_orders,
    (SELECT COUNT(*) FROM orders WHERE status = 'cancelled') as cancelled_orders,
    (SELECT COALESCE(SUM(total_price), 0) FROM orders WHERE status = 'paid') as total_revenue,
    (SELECT COUNT(*) FROM game_keys WHERE is_sold = 0) as available_keys,
    (SELECT COUNT(*) FROM game_keys WHERE is_sold = 1) as sold_keys,
    (SELECT COALESCE(SUM(total_price), 0) FROM orders WHERE status = 'paid' AND DATE(created_at) = CURDATE()) as today_revenue,
    (SELECT COUNT(*) FROM orders WHERE status = 'paid' AND DATE(created_at) = CURDATE()) as today_orders;

CREATE OR REPLACE VIEW v_product_stats AS
SELECT 
    p.id,
    p.name,
    p.platform,
    p.price,
    COUNT(DISTINCT gk_available.id) as available_keys,
    COUNT(DISTINCT gk_sold.id) as sold_keys,
    COALESCE(SUM(oi.quantity), 0) as total_sold,
    COALESCE(SUM(oi.total_price), 0) as total_revenue,
    p.view_count
FROM products p
LEFT JOIN game_keys gk_available ON gk_available.product_id = p.id AND gk_available.is_sold = 0
LEFT JOIN game_keys gk_sold ON gk_sold.product_id = p.id AND gk_sold.is_sold = 1
LEFT JOIN order_items oi ON oi.product_id = p.id
LEFT JOIN orders o ON o.id = oi.order_id AND o.status = 'paid'
GROUP BY p.id;

CREATE OR REPLACE VIEW v_daily_revenue AS
SELECT 
    DATE(created_at) as date,
    COUNT(*) as order_count,
    SUM(total_price) as revenue,
    AVG(total_price) as avg_order_value
FROM orders
WHERE status = 'paid'
GROUP BY DATE(created_at)
ORDER BY date DESC;

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_register_user$$
CREATE PROCEDURE sp_register_user(
    IN p_username VARCHAR(50),
    IN p_email VARCHAR(100),
    IN p_password_hash VARCHAR(255),
    IN p_full_name VARCHAR(100),
    IN p_phone VARCHAR(20),
    OUT p_user_id INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_user_id = 0;
        SET p_success = FALSE;
        SET p_message = 'Adatbázis hiba történt a regisztráció során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    IF LENGTH(p_username) < 3 THEN
        SET p_user_id = 0;
        SET p_success = FALSE;
        SET p_message = 'A felhasználónév legalább 3 karakter legyen';
        ROLLBACK;
    ELSEIF p_email NOT REGEXP '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$' THEN
        SET p_user_id = 0;
        SET p_success = FALSE;
        SET p_message = 'Érvénytelen email formátum';
        ROLLBACK;
    ELSEIF EXISTS (SELECT 1 FROM users WHERE username = p_username) THEN
        SET p_user_id = 0;
        SET p_success = FALSE;
        SET p_message = 'Ez a felhasználónév már foglalt';
        ROLLBACK;
    ELSEIF EXISTS (SELECT 1 FROM users WHERE email = p_email) THEN
        SET p_user_id = 0;
        SET p_success = FALSE;
        SET p_message = 'Ez az email cím már használatban van';
        ROLLBACK;
    ELSE
        INSERT INTO users (username, email, password_hash, full_name, phone, role, is_active)
        VALUES (p_username, p_email, p_password_hash, p_full_name, p_phone, 'user', 1);
        
        SET p_user_id = LAST_INSERT_ID();
        SET p_success = TRUE;
        SET p_message = 'Sikeres regisztráció';
        COMMIT;
    END IF;
END$$

DROP PROCEDURE IF EXISTS sp_login_attempt$$
CREATE PROCEDURE sp_login_attempt(
    IN p_username VARCHAR(50),
    IN p_login_success BOOLEAN,
    OUT p_is_locked BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_user_id INT;
    DECLARE v_failed_attempts INT;
    DECLARE v_locked_until TIMESTAMP;
    DECLARE v_max_attempts INT DEFAULT 5;
    DECLARE v_lock_duration INT DEFAULT 15; -- percben
    
    SELECT id, failed_login_attempts, locked_until 
    INTO v_user_id, v_failed_attempts, v_locked_until
    FROM users WHERE username = p_username;
    
    IF v_user_id IS NULL THEN
        SET p_is_locked = FALSE;
        SET p_message = 'Felhasználó nem található';
    ELSEIF v_locked_until IS NOT NULL AND v_locked_until > NOW() THEN
        SET p_is_locked = TRUE;
        SET p_message = CONCAT('Fiók zárolva ', TIMESTAMPDIFF(MINUTE, NOW(), v_locked_until), ' percig');
    ELSEIF p_login_success THEN
        UPDATE users 
        SET failed_login_attempts = 0, 
            locked_until = NULL,
            last_login_at = NOW()
        WHERE id = v_user_id;
        SET p_is_locked = FALSE;
        SET p_message = 'Sikeres bejelentkezés';
    ELSE
        SET v_failed_attempts = v_failed_attempts + 1;
        
        IF v_failed_attempts >= v_max_attempts THEN
            UPDATE users 
            SET failed_login_attempts = v_failed_attempts,
                locked_until = DATE_ADD(NOW(), INTERVAL v_lock_duration MINUTE)
            WHERE id = v_user_id;
            SET p_is_locked = TRUE;
            SET p_message = CONCAT('Túl sok sikertelen próbálkozás. Fiók zárolva ', v_lock_duration, ' percre');
        ELSE
            UPDATE users 
            SET failed_login_attempts = v_failed_attempts
            WHERE id = v_user_id;
            SET p_is_locked = FALSE;
            SET p_message = CONCAT('Hibás jelszó. Még ', v_max_attempts - v_failed_attempts, ' próbálkozás');
        END IF;
    END IF;
END$$

DROP PROCEDURE IF EXISTS sp_update_user_profile$$
CREATE PROCEDURE sp_update_user_profile(
    IN p_user_id INT,
    IN p_full_name VARCHAR(100),
    IN p_phone VARCHAR(20),
    IN p_email VARCHAR(100),
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_existing_email INT;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Adatbázis hiba történt';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    SELECT COUNT(*) INTO v_existing_email 
    FROM users 
    WHERE email = p_email AND id != p_user_id;
    
    IF v_existing_email > 0 THEN
        SET p_success = FALSE;
        SET p_message = 'Ez az email cím már használatban van';
        ROLLBACK;
    ELSE
        UPDATE users 
        SET full_name = COALESCE(p_full_name, full_name),
            phone = COALESCE(p_phone, phone),
            email = COALESCE(p_email, email)
        WHERE id = p_user_id;
        
        SET p_success = TRUE;
        SET p_message = 'Profil sikeresen frissítve';
        COMMIT;
    END IF;
END$$

DROP PROCEDURE IF EXISTS sp_change_password$$
CREATE PROCEDURE sp_change_password(
    IN p_user_id INT,
    IN p_new_password_hash VARCHAR(255),
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Adatbázis hiba történt';
    END;
    
    UPDATE users 
    SET password_hash = p_new_password_hash
    WHERE id = p_user_id;
    
    IF ROW_COUNT() > 0 THEN
        SET p_success = TRUE;
        SET p_message = 'Jelszó sikeresen módosítva';
    ELSE
        SET p_success = FALSE;
        SET p_message = 'Felhasználó nem található';
    END IF;
END$$

DROP PROCEDURE IF EXISTS sp_toggle_user_status$$
CREATE PROCEDURE sp_toggle_user_status(
    IN p_user_id INT,
    IN p_is_active BOOLEAN,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    UPDATE users SET is_active = p_is_active WHERE id = p_user_id;
    
    IF ROW_COUNT() > 0 THEN
        SET p_success = TRUE;
        SET p_message = IF(p_is_active, 'Felhasználó aktiválva', 'Felhasználó deaktiválva');
    ELSE
        SET p_success = FALSE;
        SET p_message = 'Felhasználó nem található';
    END IF;
END$$

DROP PROCEDURE IF EXISTS sp_get_user_stats$$
CREATE PROCEDURE sp_get_user_stats(IN p_user_id INT)
BEGIN
    SELECT 
        u.id,
        u.username,
        u.created_at as member_since,
        COUNT(DISTINCT o.id) as total_orders,
        COALESCE(SUM(CASE WHEN o.status = 'paid' THEN o.total_price ELSE 0 END), 0) as total_spent,
        COUNT(DISTINCT CASE WHEN o.status = 'paid' THEN o.id END) as paid_orders,
        COUNT(DISTINCT CASE WHEN o.status = 'pending' THEN o.id END) as pending_orders,
        COUNT(DISTINCT CASE WHEN o.status = 'cancelled' THEN o.id END) as cancelled_orders,
        (SELECT COUNT(*) FROM game_keys WHERE sold_to_user_id = p_user_id) as total_keys_owned,
        (SELECT COUNT(*) FROM favorites WHERE user_id = p_user_id) as favorites_count
    FROM users u
    LEFT JOIN orders o ON o.user_id = u.id
    WHERE u.id = p_user_id
    GROUP BY u.id;
END$$

DROP PROCEDURE IF EXISTS sp_add_product$$
CREATE PROCEDURE sp_add_product(
    IN p_name VARCHAR(200),
    IN p_short_description TEXT,
    IN p_long_description TEXT,
    IN p_platform ENUM('pc', 'ps', 'xbox', 'switch'),
    IN p_tag ENUM('top', 'new', 'sale', 'normal'),
    IN p_price INT,
    IN p_original_price INT,
    IN p_image_url VARCHAR(255),
    OUT p_product_id INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_discount INT DEFAULT 0;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_product_id = 0;
        SET p_success = FALSE;
        SET p_message = 'Adatbázis hiba történt';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    IF p_original_price IS NOT NULL AND p_original_price > p_price THEN
        SET v_discount = ROUND((1 - p_price / p_original_price) * 100);
    END IF;
    
    INSERT INTO products (name, short_description, long_description, platform, tag, price, original_price, discount_percent, image_url, is_active)
    VALUES (p_name, p_short_description, p_long_description, p_platform, p_tag, p_price, p_original_price, v_discount, p_image_url, 1);
    
    SET p_product_id = LAST_INSERT_ID();
    SET p_success = TRUE;
    SET p_message = 'Termék sikeresen hozzáadva';
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_update_product$$
CREATE PROCEDURE sp_update_product(
    IN p_product_id INT,
    IN p_name VARCHAR(200),
    IN p_short_description TEXT,
    IN p_long_description TEXT,
    IN p_platform ENUM('pc', 'ps', 'xbox', 'switch'),
    IN p_tag ENUM('top', 'new', 'sale', 'normal'),
    IN p_price INT,
    IN p_original_price INT,
    IN p_image_url VARCHAR(255),
    IN p_is_active BOOLEAN,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_discount INT DEFAULT 0;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Adatbázis hiba történt';
    END;
    
    IF p_original_price IS NOT NULL AND p_original_price > p_price THEN
        SET v_discount = ROUND((1 - p_price / p_original_price) * 100);
    END IF;
    
    UPDATE products SET
        name = COALESCE(p_name, name),
        short_description = COALESCE(p_short_description, short_description),
        long_description = COALESCE(p_long_description, long_description),
        platform = COALESCE(p_platform, platform),
        tag = COALESCE(p_tag, tag),
        price = COALESCE(p_price, price),
        original_price = p_original_price,
        discount_percent = v_discount,
        image_url = COALESCE(p_image_url, image_url),
        is_active = COALESCE(p_is_active, is_active)
    WHERE id = p_product_id;
    
    IF ROW_COUNT() > 0 THEN
        SET p_success = TRUE;
        SET p_message = 'Termék sikeresen frissítve';
    ELSE
        SET p_success = FALSE;
        SET p_message = 'Termék nem található';
    END IF;
END$$

DROP PROCEDURE IF EXISTS sp_increment_product_view$$
CREATE PROCEDURE sp_increment_product_view(IN p_product_id INT)
BEGIN
    UPDATE products SET view_count = view_count + 1 WHERE id = p_product_id;
END$$

DROP PROCEDURE IF EXISTS sp_search_products$$
CREATE PROCEDURE sp_search_products(
    IN p_search_term VARCHAR(100),
    IN p_platform VARCHAR(10),
    IN p_tag VARCHAR(10),
    IN p_min_price INT,
    IN p_max_price INT,
    IN p_in_stock_only BOOLEAN,
    IN p_sort_by VARCHAR(20),
    IN p_sort_order VARCHAR(4),
    IN p_limit INT,
    IN p_offset INT
)
BEGIN
    SET @sql = 'SELECT p.*, COUNT(gk.id) as available_keys FROM products p ';
    SET @sql = CONCAT(@sql, 'LEFT JOIN game_keys gk ON gk.product_id = p.id AND gk.is_sold = 0 ');
    SET @sql = CONCAT(@sql, 'WHERE p.is_active = 1 ');
    
    IF p_search_term IS NOT NULL AND p_search_term != '' THEN
        SET @sql = CONCAT(@sql, 'AND (p.name LIKE "%', p_search_term, '%" OR p.short_description LIKE "%', p_search_term, '%") ');
    END IF;
    
    IF p_platform IS NOT NULL AND p_platform != '' THEN
        SET @sql = CONCAT(@sql, 'AND p.platform = "', p_platform, '" ');
    END IF;
    
    IF p_tag IS NOT NULL AND p_tag != '' THEN
        SET @sql = CONCAT(@sql, 'AND p.tag = "', p_tag, '" ');
    END IF;
    
    IF p_min_price IS NOT NULL THEN
        SET @sql = CONCAT(@sql, 'AND p.price >= ', p_min_price, ' ');
    END IF;
    
    IF p_max_price IS NOT NULL THEN
        SET @sql = CONCAT(@sql, 'AND p.price <= ', p_max_price, ' ');
    END IF;
    
    SET @sql = CONCAT(@sql, 'GROUP BY p.id ');
    
    IF p_in_stock_only THEN
        SET @sql = CONCAT(@sql, 'HAVING available_keys > 0 ');
    END IF;
    
    IF p_sort_by IS NOT NULL THEN
        SET @sql = CONCAT(@sql, 'ORDER BY ', p_sort_by, ' ', COALESCE(p_sort_order, 'ASC'), ' ');
    ELSE
        SET @sql = CONCAT(@sql, 'ORDER BY p.name ASC ');
    END IF;
    
    IF p_limit IS NOT NULL THEN
        SET @sql = CONCAT(@sql, 'LIMIT ', p_limit, ' ');
        IF p_offset IS NOT NULL THEN
            SET @sql = CONCAT(@sql, 'OFFSET ', p_offset);
        END IF;
    END IF;
    
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
END$$

DROP PROCEDURE IF EXISTS sp_get_related_products$$
CREATE PROCEDURE sp_get_related_products(
    IN p_product_id INT,
    IN p_limit INT
)
BEGIN
    DECLARE v_limit INT;
    SET v_limit = IFNULL(p_limit, 5);
    
    SELECT p.*, COUNT(gk.id) as available_keys
    FROM products p
    LEFT JOIN game_keys gk ON gk.product_id = p.id AND gk.is_sold = 0
    WHERE p.is_active = 1 
      AND p.id != p_product_id
      AND p.platform = (SELECT platform FROM products WHERE id = p_product_id)
    GROUP BY p.id
    ORDER BY RAND()
    LIMIT v_limit;
END$$

DROP PROCEDURE IF EXISTS sp_add_game_key$$
CREATE PROCEDURE sp_add_game_key(
    IN p_product_id INT,
    IN p_key_code VARCHAR(255),
    OUT p_key_id INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_key_id = 0;
        SET p_success = FALSE;
        SET p_message = 'Adatbázis hiba történt';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    IF NOT EXISTS (SELECT 1 FROM products WHERE id = p_product_id) THEN
        SET p_key_id = 0;
        SET p_success = FALSE;
        SET p_message = 'A termék nem létezik';
        ROLLBACK;
    ELSEIF EXISTS (SELECT 1 FROM game_keys WHERE key_code = p_key_code) THEN
        SET p_key_id = 0;
        SET p_success = FALSE;
        SET p_message = 'Ez a kulcs már létezik az adatbázisban';
        ROLLBACK;
    ELSE
        INSERT INTO game_keys (product_id, key_code, is_sold) 
        VALUES (p_product_id, p_key_code, 0);
        
        SET p_key_id = LAST_INSERT_ID();
        SET p_success = TRUE;
        SET p_message = 'Kulcs sikeresen hozzáadva';
        COMMIT;
    END IF;
END$$

DROP PROCEDURE IF EXISTS sp_bulk_add_keys$$
CREATE PROCEDURE sp_bulk_add_keys(
    IN p_product_id INT,
    IN p_keys_json JSON,
    OUT p_added_count INT,
    OUT p_skipped_count INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_key VARCHAR(255);
    DECLARE v_index INT DEFAULT 0;
    DECLARE v_total INT;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_added_count = 0;
        SET p_success = FALSE;
        SET p_message = 'Adatbázis hiba történt';
        ROLLBACK;
    END;
    
    SET p_added_count = 0;
    SET p_skipped_count = 0;
    SET v_total = JSON_LENGTH(p_keys_json);
    
    START TRANSACTION;
    
    IF NOT EXISTS (SELECT 1 FROM products WHERE id = p_product_id) THEN
        SET p_success = FALSE;
        SET p_message = 'A termék nem létezik';
        ROLLBACK;
    ELSE
        WHILE v_index < v_total DO
            SET v_key = JSON_UNQUOTE(JSON_EXTRACT(p_keys_json, CONCAT('$[', v_index, ']')));
            
            IF NOT EXISTS (SELECT 1 FROM game_keys WHERE key_code = v_key) THEN
                INSERT INTO game_keys (product_id, key_code, is_sold) VALUES (p_product_id, v_key, 0);
                SET p_added_count = p_added_count + 1;
            ELSE
                SET p_skipped_count = p_skipped_count + 1;
            END IF;
            
            SET v_index = v_index + 1;
        END WHILE;
        
        SET p_success = TRUE;
        SET p_message = CONCAT(p_added_count, ' kulcs hozzáadva, ', p_skipped_count, ' kihagyva (már létezik)');
        COMMIT;
    END IF;
END$$

DROP PROCEDURE IF EXISTS sp_generate_test_keys$$
CREATE PROCEDURE sp_generate_test_keys(
    IN p_product_id INT,
    IN p_count INT,
    IN p_prefix VARCHAR(20),
    OUT p_added_count INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_counter INT DEFAULT 0;
    DECLARE v_key_code VARCHAR(255);
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_added_count = 0;
        SET p_success = FALSE;
        SET p_message = 'Adatbázis hiba történt';
        ROLLBACK;
    END;
    
    IF p_count > 1000 THEN
        SET p_added_count = 0;
        SET p_success = FALSE;
        SET p_message = 'Maximum 1000 kulcs generálható egyszerre';
    ELSEIF NOT EXISTS (SELECT 1 FROM products WHERE id = p_product_id) THEN
        SET p_added_count = 0;
        SET p_success = FALSE;
        SET p_message = 'A termék nem létezik';
    ELSE
        START TRANSACTION;
        
        WHILE v_counter < p_count DO
            SET v_key_code = CONCAT(
                COALESCE(p_prefix, 'KEY'),
                '-',
                UPPER(SUBSTRING(MD5(RAND()), 1, 4)),
                '-',
                UPPER(SUBSTRING(MD5(RAND()), 1, 4)),
                '-',
                UPPER(SUBSTRING(MD5(RAND()), 1, 4)),
                '-',
                UPPER(SUBSTRING(MD5(RAND()), 1, 4))
            );
            
            IF NOT EXISTS (SELECT 1 FROM game_keys WHERE key_code = v_key_code) THEN
                INSERT INTO game_keys (product_id, key_code, is_sold) VALUES (p_product_id, v_key_code, 0);
                SET v_counter = v_counter + 1;
            END IF;
        END WHILE;
        
        SET p_added_count = v_counter;
        SET p_success = TRUE;
        SET p_message = CONCAT(v_counter, ' teszt kulcs sikeresen generálva');
        COMMIT;
    END IF;
END$$

DROP PROCEDURE IF EXISTS sp_assign_key$$
CREATE PROCEDURE sp_assign_key(
    IN p_product_id INT,
    IN p_user_id INT,
    IN p_order_id INT,
    OUT p_key_code VARCHAR(255),
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_key_id INT;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_key_code = NULL;
        SET p_success = FALSE;
        SET p_message = 'Adatbázis hiba történt';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    SELECT id, key_code INTO v_key_id, p_key_code
    FROM game_keys
    WHERE product_id = p_product_id AND is_sold = 0
    LIMIT 1
    FOR UPDATE;
    
    IF v_key_id IS NOT NULL THEN
        UPDATE game_keys
        SET is_sold = 1, 
            sold_to_user_id = p_user_id, 
            sold_at = NOW(),
            order_id = p_order_id
        WHERE id = v_key_id;
        
        SET p_success = TRUE;
        SET p_message = 'Kulcs sikeresen kiosztva';
        COMMIT;
    ELSE
        SET p_key_code = NULL;
        SET p_success = FALSE;
        SET p_message = 'Nincs elérhető kulcs ehhez a termékhez';
        ROLLBACK;
    END IF;
END$$

DROP PROCEDURE IF EXISTS sp_check_stock$$
CREATE PROCEDURE sp_check_stock(
    IN p_product_id INT,
    OUT p_available_keys INT,
    OUT p_total_keys INT,
    OUT p_sold_keys INT
)
BEGIN
    SELECT 
        COUNT(CASE WHEN is_sold = 0 THEN 1 END),
        COUNT(*),
        COUNT(CASE WHEN is_sold = 1 THEN 1 END)
    INTO p_available_keys, p_total_keys, p_sold_keys
    FROM game_keys
    WHERE product_id = p_product_id;
END$$

DROP PROCEDURE IF EXISTS sp_get_low_stock_products$$
CREATE PROCEDURE sp_get_low_stock_products(IN p_threshold INT)
BEGIN
    SELECT 
        p.id,
        p.name,
        p.platform,
        COUNT(gk.id) as available_keys
    FROM products p
    LEFT JOIN game_keys gk ON gk.product_id = p.id AND gk.is_sold = 0
    WHERE p.is_active = 1
    GROUP BY p.id
    HAVING available_keys <= p_threshold
    ORDER BY available_keys ASC;
END$$

DROP FUNCTION IF EXISTS fn_generate_order_number$$
CREATE FUNCTION fn_generate_order_number() 
RETURNS VARCHAR(20)
DETERMINISTIC
BEGIN
    DECLARE v_order_number VARCHAR(20);
    DECLARE v_exists INT DEFAULT 1;
    
    WHILE v_exists > 0 DO
        SET v_order_number = CONCAT('GC', DATE_FORMAT(NOW(), '%Y%m%d'), LPAD(FLOOR(RAND() * 10000), 4, '0'));
        SELECT COUNT(*) INTO v_exists FROM orders WHERE order_number = v_order_number;
    END WHILE;
    
    RETURN v_order_number;
END$$

DROP PROCEDURE IF EXISTS sp_create_full_order$$
CREATE PROCEDURE sp_create_full_order(
    IN p_user_id INT,
    IN p_payment_method ENUM('online_card', 'bank_transfer', 'paypal'),
    IN p_billing_name VARCHAR(100),
    IN p_billing_address VARCHAR(255),
    IN p_billing_city VARCHAR(100),
    IN p_billing_zip VARCHAR(20),
    IN p_billing_country VARCHAR(100),
    IN p_billing_tax_number VARCHAR(50),
    IN p_coupon_code VARCHAR(50),
    OUT p_order_id INT,
    OUT p_order_number VARCHAR(20),
    OUT p_total_price INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_cart_total INT DEFAULT 0;
    DECLARE v_discount INT DEFAULT 0;
    DECLARE v_coupon_id INT;
    DECLARE v_cart_count INT;
    DECLARE v_product_id INT;
    DECLARE v_quantity INT;
    DECLARE v_price INT;
    DECLARE v_available INT;
    DECLARE done INT DEFAULT 0;
    
    DECLARE cart_cursor CURSOR FOR 
        SELECT c.product_id, c.quantity, p.price
        FROM cart c
        JOIN products p ON p.id = c.product_id
        WHERE c.user_id = p_user_id;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        SET p_order_id = 0;
        SET p_success = FALSE;
        SET p_message = CONCAT('Hiba: ', @text);
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    SELECT COUNT(*) INTO v_cart_count FROM cart WHERE user_id = p_user_id;
    
    IF v_cart_count = 0 THEN
        SET p_order_id = 0;
        SET p_success = FALSE;
        SET p_message = 'A kosár üres';
        ROLLBACK;
    ELSE
        OPEN cart_cursor;
        
        check_loop: LOOP
            FETCH cart_cursor INTO v_product_id, v_quantity, v_price;
            IF done THEN LEAVE check_loop; END IF;
            
            SELECT COUNT(*) INTO v_available 
            FROM game_keys 
            WHERE product_id = v_product_id AND is_sold = 0;
            
            IF v_available < v_quantity THEN
                SET p_order_id = 0;
                SET p_success = FALSE;
                SET p_message = CONCAT('Nincs elég készlet a termékből (ID: ', v_product_id, ')');
                CLOSE cart_cursor;
                ROLLBACK;
                LEAVE check_loop;
            END IF;
            
            SET v_cart_total = v_cart_total + (v_price * v_quantity);
        END LOOP;
        
        CLOSE cart_cursor;
        
        IF p_success IS NULL OR p_success != FALSE THEN
            IF p_coupon_code IS NOT NULL AND p_coupon_code != '' THEN
                SELECT id, 
                       CASE discount_type 
                           WHEN 'percent' THEN ROUND(v_cart_total * discount_value / 100)
                           ELSE discount_value 
                       END
                INTO v_coupon_id, v_discount
                FROM coupons
                WHERE code = p_coupon_code
                  AND is_active = 1
                  AND NOW() BETWEEN valid_from AND valid_until
                  AND (max_uses IS NULL OR used_count < max_uses)
                  AND v_cart_total >= min_order_value;
                
                IF v_coupon_id IS NOT NULL THEN
                    UPDATE coupons SET used_count = used_count + 1 WHERE id = v_coupon_id;
                END IF;
            END IF;
            
            SET p_total_price = v_cart_total - v_discount;
            SET p_order_number = fn_generate_order_number();
            
            INSERT INTO orders (
                user_id, order_number, total_price, status, payment_method,
                billing_name, billing_address, billing_city, billing_zip,
                billing_country, billing_tax_number
            ) VALUES (
                p_user_id, p_order_number, p_total_price, 'pending', p_payment_method,
                p_billing_name, p_billing_address, p_billing_city, p_billing_zip,
                p_billing_country, p_billing_tax_number
            );
            
            SET p_order_id = LAST_INSERT_ID();
            
            INSERT INTO order_items (order_id, product_id, quantity, unit_price, total_price)
            SELECT p_order_id, c.product_id, c.quantity, p.price, p.price * c.quantity
            FROM cart c
            JOIN products p ON p.id = c.product_id
            WHERE c.user_id = p_user_id;
            
            DELETE FROM cart WHERE user_id = p_user_id;
            
            IF p_payment_method != 'bank_transfer' THEN
                CALL sp_approve_order(p_order_id, @approve_success, @approve_msg);
            END IF;
            
            SET p_success = TRUE;
            SET p_message = 'Rendelés sikeresen létrehozva';
            COMMIT;
        END IF;
    END IF;
END$$

DROP PROCEDURE IF EXISTS sp_approve_order$$
CREATE PROCEDURE sp_approve_order(
    IN p_order_id INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_user_id INT;
    DECLARE v_product_id INT;
    DECLARE v_quantity INT;
    DECLARE v_assigned_keys INT DEFAULT 0;
    DECLARE v_key_code VARCHAR(255);
    DECLARE v_counter INT;
    DECLARE done INT DEFAULT 0;
    
    DECLARE order_items_cursor CURSOR FOR
        SELECT product_id, quantity
        FROM order_items
        WHERE order_id = p_order_id;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Adatbázis hiba történt a jóváhagyás során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    SELECT user_id INTO v_user_id FROM orders WHERE id = p_order_id AND status = 'pending';
    
    IF v_user_id IS NULL THEN
        SET p_success = FALSE;
        SET p_message = 'A rendelés nem található vagy nem függőben lévő státuszú';
        ROLLBACK;
    ELSE
        OPEN order_items_cursor;
        
        items_loop: LOOP
            FETCH order_items_cursor INTO v_product_id, v_quantity;
            IF done THEN LEAVE items_loop; END IF;
            
            IF (SELECT COUNT(*) FROM game_keys WHERE product_id = v_product_id AND is_sold = 0) < v_quantity THEN
                SET p_success = FALSE;
                SET p_message = CONCAT('Nincs elég kulcs a termékhez (ID: ', v_product_id, ')');
                CLOSE order_items_cursor;
                ROLLBACK;
                LEAVE items_loop;
            END IF;
            
            SET v_counter = 0;
            WHILE v_counter < v_quantity DO
                CALL sp_assign_key(v_product_id, v_user_id, p_order_id, v_key_code, @key_success, @key_msg);
                SET v_counter = v_counter + 1;
                SET v_assigned_keys = v_assigned_keys + 1;
            END WHILE;
        END LOOP;
        
        CLOSE order_items_cursor;
        
        IF p_success IS NULL OR p_success != FALSE THEN
            UPDATE orders 
            SET status = 'paid', paid_at = NOW()
            WHERE id = p_order_id;
            
            SET p_success = TRUE;
            SET p_message = CONCAT('Rendelés jóváhagyva, ', v_assigned_keys, ' kulcs kiosztva');
            COMMIT;
        END IF;
    END IF;
END$$

DROP PROCEDURE IF EXISTS sp_cancel_order$$
CREATE PROCEDURE sp_cancel_order(
    IN p_order_id INT,
    IN p_refund_keys BOOLEAN,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_status VARCHAR(20);
    DECLARE v_freed_keys INT DEFAULT 0;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Adatbázis hiba történt';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    SELECT status INTO v_status FROM orders WHERE id = p_order_id;
    
    IF v_status IS NULL THEN
        SET p_success = FALSE;
        SET p_message = 'A rendelés nem található';
        ROLLBACK;
    ELSEIF v_status = 'cancelled' THEN
        SET p_success = FALSE;
        SET p_message = 'A rendelés már törölve van';
        ROLLBACK;
    ELSE
        IF p_refund_keys AND v_status = 'paid' THEN
            UPDATE game_keys 
            SET is_sold = 0, sold_to_user_id = NULL, sold_at = NULL, order_id = NULL
            WHERE order_id = p_order_id;
            
            SET v_freed_keys = ROW_COUNT();
        END IF;
        
        UPDATE orders SET status = 'cancelled' WHERE id = p_order_id;
        
        SET p_success = TRUE;
        IF v_freed_keys > 0 THEN
            SET p_message = CONCAT('Rendelés törölve, ', v_freed_keys, ' kulcs felszabadítva');
        ELSE
            SET p_message = 'Rendelés törölve';
        END IF;
        COMMIT;
    END IF;
END$$

DROP PROCEDURE IF EXISTS sp_get_order_details$$
CREATE PROCEDURE sp_get_order_details(IN p_order_id INT, IN p_user_id INT)
BEGIN
    SELECT o.*, u.username, u.email
    FROM orders o
    JOIN users u ON u.id = o.user_id
    WHERE o.id = p_order_id 
      AND (p_user_id IS NULL OR o.user_id = p_user_id);
    
    SELECT 
        oi.*,
        p.name as product_name,
        p.platform,
        p.image_url
    FROM order_items oi
    JOIN products p ON p.id = oi.product_id
    WHERE oi.order_id = p_order_id;
    
    SELECT 
        gk.key_code,
        p.name as product_name
    FROM game_keys gk
    JOIN products p ON p.id = gk.product_id
    JOIN orders o ON o.id = gk.order_id
    WHERE gk.order_id = p_order_id
      AND (p_user_id IS NULL OR o.user_id = p_user_id);
END$$

DROP PROCEDURE IF EXISTS sp_add_to_cart$$
CREATE PROCEDURE sp_add_to_cart(
    IN p_user_id INT,
    IN p_session_id VARCHAR(100),
    IN p_product_id INT,
    IN p_quantity INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_available INT;
    DECLARE v_existing_qty INT;
    
    SELECT COUNT(*) INTO v_available 
    FROM game_keys 
    WHERE product_id = p_product_id AND is_sold = 0;
    
    IF v_available < p_quantity THEN
        SET p_success = FALSE;
        SET p_message = CONCAT('Nincs elég készlet. Elérhető: ', v_available);
    ELSE
        SELECT quantity INTO v_existing_qty
        FROM cart
        WHERE (user_id = p_user_id OR session_id = p_session_id) AND product_id = p_product_id;
        
        IF v_existing_qty IS NOT NULL THEN
            IF v_existing_qty + p_quantity > v_available THEN
                SET p_success = FALSE;
                SET p_message = CONCAT('Maximum ', v_available, ' db rendelhető');
            ELSE
                UPDATE cart 
                SET quantity = quantity + p_quantity
                WHERE (user_id = p_user_id OR session_id = p_session_id) AND product_id = p_product_id;
                
                SET p_success = TRUE;
                SET p_message = 'Kosár frissítve';
            END IF;
        ELSE
            INSERT INTO cart (user_id, session_id, product_id, quantity)
            VALUES (p_user_id, p_session_id, p_product_id, p_quantity);
            
            SET p_success = TRUE;
            SET p_message = 'Termék kosárba helyezve';
        END IF;
    END IF;
END$$

DROP PROCEDURE IF EXISTS sp_update_cart_quantity$$
CREATE PROCEDURE sp_update_cart_quantity(
    IN p_cart_id INT,
    IN p_quantity INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_product_id INT;
    DECLARE v_available INT;
    
    SELECT product_id INTO v_product_id FROM cart WHERE id = p_cart_id;
    
    IF v_product_id IS NULL THEN
        SET p_success = FALSE;
        SET p_message = 'Kosárelem nem található';
    ELSE
        SELECT COUNT(*) INTO v_available 
        FROM game_keys 
        WHERE product_id = v_product_id AND is_sold = 0;
        
        IF p_quantity > v_available THEN
            SET p_success = FALSE;
            SET p_message = CONCAT('Maximum ', v_available, ' db rendelhető');
        ELSEIF p_quantity <= 0 THEN
            DELETE FROM cart WHERE id = p_cart_id;
            SET p_success = TRUE;
            SET p_message = 'Termék eltávolítva a kosárból';
        ELSE
            UPDATE cart SET quantity = p_quantity WHERE id = p_cart_id;
            SET p_success = TRUE;
            SET p_message = 'Kosár frissítve';
        END IF;
    END IF;
END$$

DROP PROCEDURE IF EXISTS sp_get_cart$$
CREATE PROCEDURE sp_get_cart(IN p_user_id INT, IN p_session_id VARCHAR(100))
BEGIN
    SELECT 
        c.id as cart_id,
        c.product_id,
        c.quantity,
        p.name,
        p.price,
        p.image_url,
        p.platform,
        c.quantity * p.price as subtotal,
        (SELECT COUNT(*) FROM game_keys gk WHERE gk.product_id = c.product_id AND gk.is_sold = 0) as available
    FROM cart c
    JOIN products p ON p.id = c.product_id
    WHERE c.user_id = p_user_id OR c.session_id = p_session_id;
END$$

DROP PROCEDURE IF EXISTS sp_get_cart_summary$$
CREATE PROCEDURE sp_get_cart_summary(
    IN p_user_id INT,
    IN p_session_id VARCHAR(100),
    OUT p_item_count INT,
    OUT p_total_quantity INT,
    OUT p_total_price INT
)
BEGIN
    SELECT 
        COUNT(*),
        COALESCE(SUM(c.quantity), 0),
        COALESCE(SUM(c.quantity * p.price), 0)
    INTO p_item_count, p_total_quantity, p_total_price
    FROM cart c
    JOIN products p ON p.id = c.product_id
    WHERE c.user_id = p_user_id OR c.session_id = p_session_id;
END$$

DROP PROCEDURE IF EXISTS sp_merge_cart$$
CREATE PROCEDURE sp_merge_cart(
    IN p_user_id INT,
    IN p_session_id VARCHAR(100)
)
BEGIN
    UPDATE cart c1
    JOIN cart c2 ON c1.product_id = c2.product_id
    SET c1.quantity = c1.quantity + c2.quantity
    WHERE c1.user_id = p_user_id AND c2.session_id = p_session_id AND c2.user_id IS NULL;
    
    UPDATE cart
    SET user_id = p_user_id, session_id = NULL
    WHERE session_id = p_session_id AND user_id IS NULL
      AND product_id NOT IN (SELECT product_id FROM (SELECT product_id FROM cart WHERE user_id = p_user_id) as tmp);
    
    DELETE FROM cart WHERE session_id = p_session_id AND user_id IS NULL;
END$$

DROP PROCEDURE IF EXISTS sp_toggle_favorite$$
CREATE PROCEDURE sp_toggle_favorite(
    IN p_user_id INT,
    IN p_product_id INT,
    OUT p_is_favorite BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_exists INT;
    
    SELECT COUNT(*) INTO v_exists 
    FROM favorites 
    WHERE user_id = p_user_id AND product_id = p_product_id;
    
    IF v_exists > 0 THEN
        DELETE FROM favorites WHERE user_id = p_user_id AND product_id = p_product_id;
        SET p_is_favorite = FALSE;
        SET p_message = 'Eltávolítva a kedvencekből';
    ELSE
        INSERT INTO favorites (user_id, product_id) VALUES (p_user_id, p_product_id);
        SET p_is_favorite = TRUE;
        SET p_message = 'Hozzáadva a kedvencekhez';
    END IF;
END$$

DROP PROCEDURE IF EXISTS sp_get_favorites$$
CREATE PROCEDURE sp_get_favorites(IN p_user_id INT)
BEGIN
    SELECT 
        p.*,
        COUNT(gk.id) as available_keys,
        f.created_at as added_at
    FROM favorites f
    JOIN products p ON p.id = f.product_id
    LEFT JOIN game_keys gk ON gk.product_id = p.id AND gk.is_sold = 0
    WHERE f.user_id = p_user_id AND p.is_active = 1
    GROUP BY p.id
    ORDER BY f.created_at DESC;
END$$

DROP PROCEDURE IF EXISTS sp_create_coupon$$
CREATE PROCEDURE sp_create_coupon(
    IN p_code VARCHAR(50),
    IN p_discount_type ENUM('percent', 'fixed'),
    IN p_discount_value INT,
    IN p_min_order_value INT,
    IN p_max_uses INT,
    IN p_valid_from TIMESTAMP,
    IN p_valid_until TIMESTAMP,
    OUT p_coupon_id INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_coupon_id = 0;
        SET p_success = FALSE;
        SET p_message = 'Adatbázis hiba történt';
    END;
    
    IF EXISTS (SELECT 1 FROM coupons WHERE code = p_code) THEN
        SET p_coupon_id = 0;
        SET p_success = FALSE;
        SET p_message = 'Ez a kuponkód már létezik';
    ELSE
        INSERT INTO coupons (code, discount_type, discount_value, min_order_value, max_uses, valid_from, valid_until)
        VALUES (p_code, p_discount_type, p_discount_value, COALESCE(p_min_order_value, 0), p_max_uses, p_valid_from, p_valid_until);
        
        SET p_coupon_id = LAST_INSERT_ID();
        SET p_success = TRUE;
        SET p_message = 'Kupon sikeresen létrehozva';
    END IF;
END$$

DROP PROCEDURE IF EXISTS sp_validate_coupon$$
CREATE PROCEDURE sp_validate_coupon(
    IN p_code VARCHAR(50),
    IN p_order_total INT,
    OUT p_discount_amount INT,
    OUT p_is_valid BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_discount_type VARCHAR(10);
    DECLARE v_discount_value INT;
    DECLARE v_min_order_value INT;
    DECLARE v_max_uses INT;
    DECLARE v_used_count INT;
    DECLARE v_valid_from TIMESTAMP;
    DECLARE v_valid_until TIMESTAMP;
    DECLARE v_is_active BOOLEAN;
    
    SELECT discount_type, discount_value, min_order_value, max_uses, used_count, valid_from, valid_until, is_active
    INTO v_discount_type, v_discount_value, v_min_order_value, v_max_uses, v_used_count, v_valid_from, v_valid_until, v_is_active
    FROM coupons
    WHERE code = p_code;
    
    IF v_discount_type IS NULL THEN
        SET p_discount_amount = 0;
        SET p_is_valid = FALSE;
        SET p_message = 'Érvénytelen kuponkód';
    ELSEIF NOT v_is_active THEN
        SET p_discount_amount = 0;
        SET p_is_valid = FALSE;
        SET p_message = 'Ez a kupon inaktív';
    ELSEIF NOW() < v_valid_from THEN
        SET p_discount_amount = 0;
        SET p_is_valid = FALSE;
        SET p_message = 'Ez a kupon még nem érvényes';
    ELSEIF NOW() > v_valid_until THEN
        SET p_discount_amount = 0;
        SET p_is_valid = FALSE;
        SET p_message = 'Ez a kupon lejárt';
    ELSEIF v_max_uses IS NOT NULL AND v_used_count >= v_max_uses THEN
        SET p_discount_amount = 0;
        SET p_is_valid = FALSE;
        SET p_message = 'Ez a kupon elérte a maximális felhasználási számot';
    ELSEIF p_order_total < v_min_order_value THEN
        SET p_discount_amount = 0;
        SET p_is_valid = FALSE;
        SET p_message = CONCAT('Minimum rendelési érték: ', v_min_order_value, ' Ft');
    ELSE
        IF v_discount_type = 'percent' THEN
            SET p_discount_amount = ROUND(p_order_total * v_discount_value / 100);
        ELSE
            SET p_discount_amount = v_discount_value;
        END IF;
        
        IF p_discount_amount > p_order_total THEN
            SET p_discount_amount = p_order_total;
        END IF;
        
        SET p_is_valid = TRUE;
        SET p_message = CONCAT('Kupon érvényes! Kedvezmény: ', p_discount_amount, ' Ft');
    END IF;
END$$

DROP PROCEDURE IF EXISTS sp_get_daily_report$$
CREATE PROCEDURE sp_get_daily_report(IN p_date DATE)
BEGIN
    SELECT 
        p_date as report_date,
        (SELECT COUNT(*) FROM users WHERE DATE(created_at) = p_date) as new_users,
        (SELECT COUNT(*) FROM orders WHERE DATE(created_at) = p_date) as total_orders,
        (SELECT COUNT(*) FROM orders WHERE DATE(created_at) = p_date AND status = 'paid') as paid_orders,
        (SELECT COALESCE(SUM(total_price), 0) FROM orders WHERE DATE(created_at) = p_date AND status = 'paid') as revenue,
        (SELECT COUNT(*) FROM game_keys WHERE DATE(sold_at) = p_date) as keys_sold;
END$$

DROP PROCEDURE IF EXISTS sp_get_period_report$$
CREATE PROCEDURE sp_get_period_report(
    IN p_start_date DATE,
    IN p_end_date DATE
)
BEGIN
    SELECT 
        p_start_date as period_start,
        p_end_date as period_end,
        (SELECT COUNT(*) FROM users WHERE DATE(created_at) BETWEEN p_start_date AND p_end_date) as new_users,
        (SELECT COUNT(*) FROM orders WHERE DATE(created_at) BETWEEN p_start_date AND p_end_date AND status = 'paid') as total_orders,
        (SELECT COALESCE(SUM(total_price), 0) FROM orders WHERE DATE(created_at) BETWEEN p_start_date AND p_end_date AND status = 'paid') as total_revenue,
        (SELECT COALESCE(AVG(total_price), 0) FROM orders WHERE DATE(created_at) BETWEEN p_start_date AND p_end_date AND status = 'paid') as avg_order_value,
        (SELECT COUNT(*) FROM game_keys WHERE DATE(sold_at) BETWEEN p_start_date AND p_end_date) as keys_sold;
    
    SELECT 
        DATE(created_at) as date,
        COUNT(*) as orders,
        SUM(total_price) as revenue
    FROM orders
    WHERE DATE(created_at) BETWEEN p_start_date AND p_end_date AND status = 'paid'
    GROUP BY DATE(created_at)
    ORDER BY date;
END$$

DROP PROCEDURE IF EXISTS sp_get_top_products_report$$
CREATE PROCEDURE sp_get_top_products_report(
    IN p_start_date DATE,
    IN p_end_date DATE,
    IN p_limit INT
)
BEGIN
    DECLARE v_limit INT;
    SET v_limit = IFNULL(p_limit, 10);
    
    SELECT 
        p.id,
        p.name,
        p.platform,
        COUNT(DISTINCT o.id) as order_count,
        SUM(oi.quantity) as units_sold,
        SUM(oi.total_price) as revenue
    FROM order_items oi
    JOIN orders o ON o.id = oi.order_id
    JOIN products p ON p.id = oi.product_id
    WHERE o.status = 'paid'
      AND (p_start_date IS NULL OR DATE(o.created_at) >= p_start_date)
      AND (p_end_date IS NULL OR DATE(o.created_at) <= p_end_date)
    GROUP BY p.id
    ORDER BY revenue DESC
    LIMIT v_limit;
END$$

DROP PROCEDURE IF EXISTS sp_get_platform_stats$$
CREATE PROCEDURE sp_get_platform_stats()
BEGIN
    SELECT 
        p.platform,
        COUNT(DISTINCT p.id) as product_count,
        COUNT(DISTINCT CASE WHEN gk.is_sold = 0 THEN gk.id END) as available_keys,
        COUNT(DISTINCT CASE WHEN gk.is_sold = 1 THEN gk.id END) as sold_keys,
        COALESCE(SUM(CASE WHEN o.status = 'paid' THEN oi.total_price END), 0) as total_revenue
    FROM products p
    LEFT JOIN game_keys gk ON gk.product_id = p.id
    LEFT JOIN order_items oi ON oi.product_id = p.id
    LEFT JOIN orders o ON o.id = oi.order_id
    WHERE p.is_active = 1
    GROUP BY p.platform;
END$$

DROP PROCEDURE IF EXISTS sp_get_user_activity_report$$
CREATE PROCEDURE sp_get_user_activity_report(IN p_limit INT)
BEGIN
    DECLARE v_limit INT;
    SET v_limit = IFNULL(p_limit, 20);
    
    SELECT 
        u.id,
        u.username,
        u.email,
        u.created_at as registered_at,
        u.last_login_at,
        COUNT(DISTINCT o.id) as total_orders,
        COALESCE(SUM(CASE WHEN o.status = 'paid' THEN o.total_price END), 0) as total_spent,
        MAX(o.created_at) as last_order_date
    FROM users u
    LEFT JOIN orders o ON o.user_id = u.id
    WHERE u.role = 'user'
    GROUP BY u.id
    ORDER BY total_spent DESC
    LIMIT v_limit;
END$$

DROP PROCEDURE IF EXISTS sp_users_create$$
CREATE PROCEDURE sp_users_create(
    IN p_username VARCHAR(50),
    IN p_email VARCHAR(100),
    IN p_password_hash VARCHAR(255),
    IN p_full_name VARCHAR(100),
    IN p_phone VARCHAR(20),
    IN p_role ENUM('user', 'admin'),
    OUT p_new_id INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a felhasználó létrehozása során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    IF EXISTS (SELECT 1 FROM users WHERE username = p_username) THEN
        SET p_success = FALSE;
        SET p_message = 'Ez a felhasználónév már foglalt';
        SET p_new_id = NULL;
    ELSEIF EXISTS (SELECT 1 FROM users WHERE email = p_email) THEN
        SET p_success = FALSE;
        SET p_message = 'Ez az email cím már regisztrálva van';
        SET p_new_id = NULL;
    ELSE
        INSERT INTO users (username, email, password_hash, full_name, phone, role, is_active)
        VALUES (p_username, p_email, p_password_hash, p_full_name, p_phone, IFNULL(p_role, 'user'), 1);
        
        SET p_new_id = LAST_INSERT_ID();
        SET p_success = TRUE;
        SET p_message = 'Felhasználó sikeresen létrehozva';
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_users_get_by_id$$
CREATE PROCEDURE sp_users_get_by_id(IN p_id INT)
BEGIN
    SELECT id, username, email, full_name, phone, role, is_active, 
           created_at, updated_at, last_login_at
    FROM users
    WHERE id = p_id;
END$$

DROP PROCEDURE IF EXISTS sp_users_get_all$$
CREATE PROCEDURE sp_users_get_all(
    IN p_page INT,
    IN p_page_size INT,
    IN p_role ENUM('user', 'admin'),
    IN p_is_active TINYINT
)
BEGIN
    DECLARE v_offset INT;
    DECLARE v_limit INT;
    SET v_limit = IFNULL(p_page_size, 20);
    SET v_offset = (IFNULL(p_page, 1) - 1) * v_limit;
    
    SELECT id, username, email, full_name, phone, role, is_active, 
           created_at, updated_at, last_login_at
    FROM users
    WHERE (p_role IS NULL OR role = p_role)
      AND (p_is_active IS NULL OR is_active = p_is_active)
    ORDER BY created_at DESC
    LIMIT v_limit OFFSET v_offset;
    
    SELECT COUNT(*) as total_count
    FROM users
    WHERE (p_role IS NULL OR role = p_role)
      AND (p_is_active IS NULL OR is_active = p_is_active);
END$$

DROP PROCEDURE IF EXISTS sp_users_update$$
CREATE PROCEDURE sp_users_update(
    IN p_id INT,
    IN p_username VARCHAR(50),
    IN p_email VARCHAR(100),
    IN p_full_name VARCHAR(100),
    IN p_phone VARCHAR(20),
    IN p_role ENUM('user', 'admin'),
    IN p_is_active TINYINT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a felhasználó módosítása során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    IF NOT EXISTS (SELECT 1 FROM users WHERE id = p_id) THEN
        SET p_success = FALSE;
        SET p_message = 'A felhasználó nem található';
    ELSEIF p_username IS NOT NULL AND EXISTS (SELECT 1 FROM users WHERE username = p_username AND id != p_id) THEN
        SET p_success = FALSE;
        SET p_message = 'Ez a felhasználónév már foglalt';
    ELSEIF p_email IS NOT NULL AND EXISTS (SELECT 1 FROM users WHERE email = p_email AND id != p_id) THEN
        SET p_success = FALSE;
        SET p_message = 'Ez az email cím már használatban van';
    ELSE
        UPDATE users SET
            username = IFNULL(p_username, username),
            email = IFNULL(p_email, email),
            full_name = IFNULL(p_full_name, full_name),
            phone = IFNULL(p_phone, phone),
            role = IFNULL(p_role, role),
            is_active = IFNULL(p_is_active, is_active),
            updated_at = CURRENT_TIMESTAMP
        WHERE id = p_id;
        
        SET p_success = TRUE;
        SET p_message = 'Felhasználó sikeresen módosítva';
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_users_delete$$
CREATE PROCEDURE sp_users_delete(
    IN p_id INT,
    IN p_hard_delete BOOLEAN,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a felhasználó törlése során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    IF NOT EXISTS (SELECT 1 FROM users WHERE id = p_id) THEN
        SET p_success = FALSE;
        SET p_message = 'A felhasználó nem található';
    ELSEIF p_hard_delete = TRUE THEN
        DELETE FROM users WHERE id = p_id;
        SET p_success = TRUE;
        SET p_message = 'Felhasználó véglegesen törölve';
    ELSE
        UPDATE users SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = p_id;
        SET p_success = TRUE;
        SET p_message = 'Felhasználó inaktiválva';
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_users_search$$
CREATE PROCEDURE sp_users_search(
    IN p_search_term VARCHAR(100),
    IN p_limit INT
)
BEGIN
    DECLARE v_limit INT;
    SET v_limit = IFNULL(p_limit, 20);
    
    SELECT id, username, email, full_name, phone, role, is_active, created_at
    FROM users
    WHERE username LIKE CONCAT('%', p_search_term, '%')
       OR email LIKE CONCAT('%', p_search_term, '%')
       OR full_name LIKE CONCAT('%', p_search_term, '%')
    ORDER BY 
        CASE WHEN username LIKE CONCAT(p_search_term, '%') THEN 0 ELSE 1 END,
        username
    LIMIT v_limit;
END$$

DROP PROCEDURE IF EXISTS sp_products_create$$
CREATE PROCEDURE sp_products_create(
    IN p_name VARCHAR(200),
    IN p_short_description TEXT,
    IN p_long_description TEXT,
    IN p_platform ENUM('pc', 'ps', 'xbox', 'switch'),
    IN p_tag ENUM('top', 'new', 'sale', 'normal'),
    IN p_price INT,
    IN p_original_price INT,
    IN p_discount_percent INT,
    IN p_image_url VARCHAR(255),
    OUT p_new_id INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a termék létrehozása során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    INSERT INTO products (name, short_description, long_description, platform, tag, 
                         price, original_price, discount_percent, image_url, is_active)
    VALUES (p_name, p_short_description, p_long_description, p_platform, 
            IFNULL(p_tag, 'normal'), p_price, p_original_price, 
            IFNULL(p_discount_percent, 0), p_image_url, 1);
    
    SET p_new_id = LAST_INSERT_ID();
    SET p_success = TRUE;
    SET p_message = 'Termék sikeresen létrehozva';
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_products_get_by_id$$
CREATE PROCEDURE sp_products_get_by_id(IN p_id INT)
BEGIN
    SELECT p.*, 
           COUNT(CASE WHEN gk.is_sold = 0 THEN 1 END) as available_keys,
           COUNT(gk.id) as total_keys
    FROM products p
    LEFT JOIN game_keys gk ON gk.product_id = p.id
    WHERE p.id = p_id
    GROUP BY p.id;
END$$

DROP PROCEDURE IF EXISTS sp_products_get_all$$
CREATE PROCEDURE sp_products_get_all(
    IN p_page INT,
    IN p_page_size INT,
    IN p_platform ENUM('pc', 'ps', 'xbox', 'switch'),
    IN p_tag ENUM('top', 'new', 'sale', 'normal'),
    IN p_is_active TINYINT,
    IN p_min_price INT,
    IN p_max_price INT,
    IN p_order_by VARCHAR(20),
    IN p_order_dir VARCHAR(4)
)
BEGIN
    DECLARE v_offset INT;
    DECLARE v_limit INT;
    SET v_limit = IFNULL(p_page_size, 20);
    SET v_offset = (IFNULL(p_page, 1) - 1) * v_limit;
    
    SELECT p.*, 
           COUNT(CASE WHEN gk.is_sold = 0 THEN 1 END) as available_keys
    FROM products p
    LEFT JOIN game_keys gk ON gk.product_id = p.id
    WHERE (p_platform IS NULL OR p.platform = p_platform)
      AND (p_tag IS NULL OR p.tag = p_tag)
      AND (p_is_active IS NULL OR p.is_active = p_is_active)
      AND (p_min_price IS NULL OR p.price >= p_min_price)
      AND (p_max_price IS NULL OR p.price <= p_max_price)
    GROUP BY p.id
    ORDER BY 
        CASE WHEN p_order_by = 'price' AND p_order_dir = 'ASC' THEN p.price END ASC,
        CASE WHEN p_order_by = 'price' AND p_order_dir = 'DESC' THEN p.price END DESC,
        CASE WHEN p_order_by = 'name' AND p_order_dir = 'ASC' THEN p.name END ASC,
        CASE WHEN p_order_by = 'name' AND p_order_dir = 'DESC' THEN p.name END DESC,
        CASE WHEN p_order_by = 'created_at' OR p_order_by IS NULL THEN p.created_at END DESC
    LIMIT v_limit OFFSET v_offset;
    
    SELECT COUNT(*) as total_count
    FROM products p
    WHERE (p_platform IS NULL OR p.platform = p_platform)
      AND (p_tag IS NULL OR p.tag = p_tag)
      AND (p_is_active IS NULL OR p.is_active = p_is_active)
      AND (p_min_price IS NULL OR p.price >= p_min_price)
      AND (p_max_price IS NULL OR p.price <= p_max_price);
END$$

DROP PROCEDURE IF EXISTS sp_products_update$$
CREATE PROCEDURE sp_products_update(
    IN p_id INT,
    IN p_name VARCHAR(200),
    IN p_short_description TEXT,
    IN p_long_description TEXT,
    IN p_platform ENUM('pc', 'ps', 'xbox', 'switch'),
    IN p_tag ENUM('top', 'new', 'sale', 'normal'),
    IN p_price INT,
    IN p_original_price INT,
    IN p_discount_percent INT,
    IN p_image_url VARCHAR(255),
    IN p_is_active TINYINT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a termék módosítása során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    IF NOT EXISTS (SELECT 1 FROM products WHERE id = p_id) THEN
        SET p_success = FALSE;
        SET p_message = 'A termék nem található';
    ELSE
        UPDATE products SET
            name = IFNULL(p_name, name),
            short_description = IFNULL(p_short_description, short_description),
            long_description = IFNULL(p_long_description, long_description),
            platform = IFNULL(p_platform, platform),
            tag = IFNULL(p_tag, tag),
            price = IFNULL(p_price, price),
            original_price = IFNULL(p_original_price, original_price),
            discount_percent = IFNULL(p_discount_percent, discount_percent),
            image_url = IFNULL(p_image_url, image_url),
            is_active = IFNULL(p_is_active, is_active),
            updated_at = CURRENT_TIMESTAMP
        WHERE id = p_id;
        
        SET p_success = TRUE;
        SET p_message = 'Termék sikeresen módosítva';
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_products_delete$$
CREATE PROCEDURE sp_products_delete(
    IN p_id INT,
    IN p_hard_delete BOOLEAN,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_sold_keys INT;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a termék törlése során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    IF NOT EXISTS (SELECT 1 FROM products WHERE id = p_id) THEN
        SET p_success = FALSE;
        SET p_message = 'A termék nem található';
    ELSE
        SELECT COUNT(*) INTO v_sold_keys FROM game_keys WHERE product_id = p_id AND is_sold = 1;
        
        IF p_hard_delete = TRUE AND v_sold_keys > 0 THEN
            SET p_success = FALSE;
            SET p_message = 'Nem törölhető: vannak eladott kulcsok a termékhez';
        ELSEIF p_hard_delete = TRUE THEN
            DELETE FROM products WHERE id = p_id;
            SET p_success = TRUE;
            SET p_message = 'Termék véglegesen törölve';
        ELSE
            UPDATE products SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = p_id;
            SET p_success = TRUE;
            SET p_message = 'Termék inaktiválva';
        END IF;
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_products_search$$
CREATE PROCEDURE sp_products_search(
    IN p_search_term VARCHAR(100),
    IN p_platform ENUM('pc', 'ps', 'xbox', 'switch'),
    IN p_limit INT
)
BEGIN
    DECLARE v_limit INT;
    SET v_limit = IFNULL(p_limit, 20);
    
    SELECT p.*, 
           COUNT(CASE WHEN gk.is_sold = 0 THEN 1 END) as available_keys
    FROM products p
    LEFT JOIN game_keys gk ON gk.product_id = p.id
    WHERE p.is_active = 1
      AND (p_platform IS NULL OR p.platform = p_platform)
      AND (p.name LIKE CONCAT('%', p_search_term, '%')
           OR p.short_description LIKE CONCAT('%', p_search_term, '%'))
    GROUP BY p.id
    ORDER BY 
        CASE WHEN p.name LIKE CONCAT(p_search_term, '%') THEN 0 ELSE 1 END,
        p.name
    LIMIT v_limit;
END$$

DROP PROCEDURE IF EXISTS sp_game_keys_create$$
CREATE PROCEDURE sp_game_keys_create(
    IN p_product_id INT,
    IN p_key_code VARCHAR(255),
    OUT p_new_id INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a kulcs hozzáadása során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    IF NOT EXISTS (SELECT 1 FROM products WHERE id = p_product_id) THEN
        SET p_success = FALSE;
        SET p_message = 'A megadott termék nem létezik';
        SET p_new_id = NULL;
    ELSEIF EXISTS (SELECT 1 FROM game_keys WHERE key_code = p_key_code) THEN
        SET p_success = FALSE;
        SET p_message = 'Ez a kulcs már létezik az adatbázisban';
        SET p_new_id = NULL;
    ELSE
        INSERT INTO game_keys (product_id, key_code, is_sold)
        VALUES (p_product_id, p_key_code, 0);
        
        SET p_new_id = LAST_INSERT_ID();
        SET p_success = TRUE;
        SET p_message = 'Kulcs sikeresen hozzáadva';
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_game_keys_create_bulk$$
CREATE PROCEDURE sp_game_keys_create_bulk(
    IN p_product_id INT,
    IN p_keys_json JSON,
    OUT p_added_count INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_key VARCHAR(255);
    DECLARE v_index INT DEFAULT 0;
    DECLARE v_total INT;
    DECLARE v_added INT DEFAULT 0;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a kulcsok hozzáadása során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    IF NOT EXISTS (SELECT 1 FROM products WHERE id = p_product_id) THEN
        SET p_success = FALSE;
        SET p_message = 'A megadott termék nem létezik';
        SET p_added_count = 0;
    ELSE
        SET v_total = JSON_LENGTH(p_keys_json);
        
        WHILE v_index < v_total DO
            SET v_key = JSON_UNQUOTE(JSON_EXTRACT(p_keys_json, CONCAT('$[', v_index, ']')));
            
            IF NOT EXISTS (SELECT 1 FROM game_keys WHERE key_code = v_key) THEN
                INSERT INTO game_keys (product_id, key_code, is_sold) VALUES (p_product_id, v_key, 0);
                SET v_added = v_added + 1;
            END IF;
            
            SET v_index = v_index + 1;
        END WHILE;
        
        SET p_added_count = v_added;
        SET p_success = TRUE;
        SET p_message = CONCAT(v_added, ' kulcs sikeresen hozzáadva (', v_total - v_added, ' duplikált)');
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_game_keys_get_by_id$$
CREATE PROCEDURE sp_game_keys_get_by_id(IN p_id INT)
BEGIN
    SELECT gk.*, p.name as product_name, u.username as sold_to_username
    FROM game_keys gk
    LEFT JOIN products p ON p.id = gk.product_id
    LEFT JOIN users u ON u.id = gk.sold_to_user_id
    WHERE gk.id = p_id;
END$$

DROP PROCEDURE IF EXISTS sp_game_keys_get_by_product$$
CREATE PROCEDURE sp_game_keys_get_by_product(
    IN p_product_id INT,
    IN p_is_sold TINYINT,
    IN p_page INT,
    IN p_page_size INT
)
BEGIN
    DECLARE v_offset INT;
    DECLARE v_limit INT;
    SET v_limit = IFNULL(p_page_size, 50);
    SET v_offset = (IFNULL(p_page, 1) - 1) * v_limit;
    
    SELECT gk.*, u.username as sold_to_username
    FROM game_keys gk
    LEFT JOIN users u ON u.id = gk.sold_to_user_id
    WHERE gk.product_id = p_product_id
      AND (p_is_sold IS NULL OR gk.is_sold = p_is_sold)
    ORDER BY gk.created_at DESC
    LIMIT v_limit OFFSET v_offset;
    
    SELECT COUNT(*) as total_count,
           SUM(CASE WHEN is_sold = 0 THEN 1 ELSE 0 END) as available_count,
           SUM(CASE WHEN is_sold = 1 THEN 1 ELSE 0 END) as sold_count
    FROM game_keys
    WHERE product_id = p_product_id;
END$$

DROP PROCEDURE IF EXISTS sp_game_keys_update$$
CREATE PROCEDURE sp_game_keys_update(
    IN p_id INT,
    IN p_key_code VARCHAR(255),
    IN p_product_id INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_is_sold TINYINT;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a kulcs módosítása során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    SELECT is_sold INTO v_is_sold FROM game_keys WHERE id = p_id;
    
    IF v_is_sold IS NULL THEN
        SET p_success = FALSE;
        SET p_message = 'A kulcs nem található';
    ELSEIF v_is_sold = 1 THEN
        SET p_success = FALSE;
        SET p_message = 'Eladott kulcs nem módosítható';
    ELSEIF p_key_code IS NOT NULL AND EXISTS (SELECT 1 FROM game_keys WHERE key_code = p_key_code AND id != p_id) THEN
        SET p_success = FALSE;
        SET p_message = 'Ez a kulcs már létezik';
    ELSE
        UPDATE game_keys SET
            key_code = IFNULL(p_key_code, key_code),
            product_id = IFNULL(p_product_id, product_id)
        WHERE id = p_id;
        
        SET p_success = TRUE;
        SET p_message = 'Kulcs sikeresen módosítva';
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_game_keys_delete$$
CREATE PROCEDURE sp_game_keys_delete(
    IN p_id INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_is_sold TINYINT;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a kulcs törlése során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    SELECT is_sold INTO v_is_sold FROM game_keys WHERE id = p_id;
    
    IF v_is_sold IS NULL THEN
        SET p_success = FALSE;
        SET p_message = 'A kulcs nem található';
    ELSEIF v_is_sold = 1 THEN
        SET p_success = FALSE;
        SET p_message = 'Eladott kulcs nem törölhető';
    ELSE
        DELETE FROM game_keys WHERE id = p_id;
        SET p_success = TRUE;
        SET p_message = 'Kulcs sikeresen törölve';
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_orders_create$$
CREATE PROCEDURE sp_orders_create(
    IN p_user_id INT,
    IN p_payment_method ENUM('online_card', 'bank_transfer', 'paypal'),
    IN p_billing_name VARCHAR(100),
    IN p_billing_address VARCHAR(255),
    IN p_billing_city VARCHAR(100),
    IN p_billing_zip VARCHAR(20),
    IN p_billing_country VARCHAR(100),
    IN p_billing_tax_number VARCHAR(50),
    IN p_notes TEXT,
    OUT p_new_id INT,
    OUT p_order_number VARCHAR(20),
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a rendelés létrehozása során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    IF NOT EXISTS (SELECT 1 FROM users WHERE id = p_user_id AND is_active = 1) THEN
        SET p_success = FALSE;
        SET p_message = 'Érvénytelen felhasználó';
        SET p_new_id = NULL;
    ELSE
        INSERT INTO orders (user_id, total_price, status, payment_method, 
                           billing_name, billing_address, billing_city, 
                           billing_zip, billing_country, billing_tax_number, notes)
        VALUES (p_user_id, 0, 'pending', p_payment_method,
                p_billing_name, p_billing_address, p_billing_city,
                p_billing_zip, p_billing_country, p_billing_tax_number, p_notes);
        
        SET p_new_id = LAST_INSERT_ID();
        SELECT order_number INTO p_order_number FROM orders WHERE id = p_new_id;
        SET p_success = TRUE;
        SET p_message = 'Rendelés sikeresen létrehozva';
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_orders_get_by_id$$
CREATE PROCEDURE sp_orders_get_by_id(IN p_id INT)
BEGIN
    SELECT o.*, u.username, u.email as user_email
    FROM orders o
    JOIN users u ON u.id = o.user_id
    WHERE o.id = p_id;
    
    SELECT oi.*, p.name as product_name, p.platform
    FROM order_items oi
    JOIN products p ON p.id = oi.product_id
    WHERE oi.order_id = p_id;
END$$

DROP PROCEDURE IF EXISTS sp_orders_get_all$$
CREATE PROCEDURE sp_orders_get_all(
    IN p_page INT,
    IN p_page_size INT,
    IN p_status ENUM('pending', 'paid', 'cancelled', 'refunded'),
    IN p_user_id INT,
    IN p_date_from DATE,
    IN p_date_to DATE
)
BEGIN
    DECLARE v_offset INT;
    DECLARE v_limit INT;
    SET v_limit = IFNULL(p_page_size, 20);
    SET v_offset = (IFNULL(p_page, 1) - 1) * v_limit;
    
    SELECT o.*, u.username, u.email as user_email,
           (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) as item_count
    FROM orders o
    JOIN users u ON u.id = o.user_id
    WHERE (p_status IS NULL OR o.status = p_status)
      AND (p_user_id IS NULL OR o.user_id = p_user_id)
      AND (p_date_from IS NULL OR DATE(o.created_at) >= p_date_from)
      AND (p_date_to IS NULL OR DATE(o.created_at) <= p_date_to)
    ORDER BY o.created_at DESC
    LIMIT v_limit OFFSET v_offset;
    
    SELECT COUNT(*) as total_count,
           SUM(CASE WHEN o.status = 'paid' THEN o.total_price ELSE 0 END) as total_revenue
    FROM orders o
    WHERE (p_status IS NULL OR o.status = p_status)
      AND (p_user_id IS NULL OR o.user_id = p_user_id)
      AND (p_date_from IS NULL OR DATE(o.created_at) >= p_date_from)
      AND (p_date_to IS NULL OR DATE(o.created_at) <= p_date_to);
END$$

DROP PROCEDURE IF EXISTS sp_orders_update$$
CREATE PROCEDURE sp_orders_update(
    IN p_id INT,
    IN p_status ENUM('pending', 'paid', 'cancelled', 'refunded'),
    IN p_payment_transaction_id VARCHAR(100),
    IN p_notes TEXT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_current_status VARCHAR(20);
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a rendelés módosítása során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    SELECT status INTO v_current_status FROM orders WHERE id = p_id;
    
    IF v_current_status IS NULL THEN
        SET p_success = FALSE;
        SET p_message = 'A rendelés nem található';
    ELSE
        UPDATE orders SET
            status = IFNULL(p_status, status),
            payment_transaction_id = IFNULL(p_payment_transaction_id, payment_transaction_id),
            notes = IFNULL(p_notes, notes),
            paid_at = CASE WHEN p_status = 'paid' AND paid_at IS NULL THEN CURRENT_TIMESTAMP ELSE paid_at END,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = p_id;
        
        SET p_success = TRUE;
        SET p_message = 'Rendelés sikeresen módosítva';
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_orders_delete$$
CREATE PROCEDURE sp_orders_delete(
    IN p_id INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_status VARCHAR(20);
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a rendelés törlése során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    SELECT status INTO v_status FROM orders WHERE id = p_id;
    
    IF v_status IS NULL THEN
        SET p_success = FALSE;
        SET p_message = 'A rendelés nem található';
    ELSEIF v_status != 'pending' THEN
        SET p_success = FALSE;
        SET p_message = 'Csak függőben lévő rendelés törölhető';
    ELSE
        DELETE FROM orders WHERE id = p_id;
        SET p_success = TRUE;
        SET p_message = 'Rendelés sikeresen törölve';
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_orders_get_by_user$$
CREATE PROCEDURE sp_orders_get_by_user(
    IN p_user_id INT,
    IN p_page INT,
    IN p_page_size INT
)
BEGIN
    DECLARE v_offset INT;
    DECLARE v_limit INT;
    SET v_limit = IFNULL(p_page_size, 10);
    SET v_offset = (IFNULL(p_page, 1) - 1) * v_limit;
    
    SELECT o.*,
           (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) as item_count
    FROM orders o
    WHERE o.user_id = p_user_id
    ORDER BY o.created_at DESC
    LIMIT v_limit OFFSET v_offset;
END$$

DROP PROCEDURE IF EXISTS sp_order_items_create$$
CREATE PROCEDURE sp_order_items_create(
    IN p_order_id INT,
    IN p_product_id INT,
    IN p_quantity INT,
    OUT p_new_id INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_order_status VARCHAR(20);
    DECLARE v_unit_price INT;
    DECLARE v_available_keys INT;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a tétel hozzáadása során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    SELECT status INTO v_order_status FROM orders WHERE id = p_order_id;
    SELECT price INTO v_unit_price FROM products WHERE id = p_product_id AND is_active = 1;
    SELECT COUNT(*) INTO v_available_keys FROM game_keys WHERE product_id = p_product_id AND is_sold = 0;
    
    IF v_order_status IS NULL THEN
        SET p_success = FALSE;
        SET p_message = 'A rendelés nem található';
    ELSEIF v_order_status != 'pending' THEN
        SET p_success = FALSE;
        SET p_message = 'Csak függőben lévő rendeléshez adható tétel';
    ELSEIF v_unit_price IS NULL THEN
        SET p_success = FALSE;
        SET p_message = 'A termék nem található vagy inaktív';
    ELSEIF v_available_keys < IFNULL(p_quantity, 1) THEN
        SET p_success = FALSE;
        SET p_message = CONCAT('Nincs elég készlet. Elérhető: ', v_available_keys);
    ELSE
        INSERT INTO order_items (order_id, product_id, quantity, unit_price, total_price)
        VALUES (p_order_id, p_product_id, IFNULL(p_quantity, 1), v_unit_price, v_unit_price * IFNULL(p_quantity, 1));
        
        SET p_new_id = LAST_INSERT_ID();
        
        UPDATE orders SET total_price = (
            SELECT SUM(total_price) FROM order_items WHERE order_id = p_order_id
        ) WHERE id = p_order_id;
        
        SET p_success = TRUE;
        SET p_message = 'Tétel sikeresen hozzáadva';
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_order_items_get_by_order$$
CREATE PROCEDURE sp_order_items_get_by_order(IN p_order_id INT)
BEGIN
    SELECT oi.*, p.name as product_name, p.platform, p.image_url
    FROM order_items oi
    JOIN products p ON p.id = oi.product_id
    WHERE oi.order_id = p_order_id;
END$$

DROP PROCEDURE IF EXISTS sp_order_items_get_by_id$$
CREATE PROCEDURE sp_order_items_get_by_id(IN p_id INT)
BEGIN
    SELECT oi.*, p.name as product_name, p.platform, o.order_number, o.status as order_status
    FROM order_items oi
    JOIN products p ON p.id = oi.product_id
    JOIN orders o ON o.id = oi.order_id
    WHERE oi.id = p_id;
END$$

DROP PROCEDURE IF EXISTS sp_order_items_update$$
CREATE PROCEDURE sp_order_items_update(
    IN p_id INT,
    IN p_quantity INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_order_id INT;
    DECLARE v_order_status VARCHAR(20);
    DECLARE v_product_id INT;
    DECLARE v_unit_price INT;
    DECLARE v_available_keys INT;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a tétel módosítása során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    SELECT oi.order_id, o.status, oi.product_id, oi.unit_price
    INTO v_order_id, v_order_status, v_product_id, v_unit_price
    FROM order_items oi
    JOIN orders o ON o.id = oi.order_id
    WHERE oi.id = p_id;
    
    SELECT COUNT(*) INTO v_available_keys FROM game_keys WHERE product_id = v_product_id AND is_sold = 0;
    
    IF v_order_id IS NULL THEN
        SET p_success = FALSE;
        SET p_message = 'A tétel nem található';
    ELSEIF v_order_status != 'pending' THEN
        SET p_success = FALSE;
        SET p_message = 'Csak függőben lévő rendelés tétele módosítható';
    ELSEIF p_quantity > v_available_keys THEN
        SET p_success = FALSE;
        SET p_message = CONCAT('Nincs elég készlet. Elérhető: ', v_available_keys);
    ELSE
        UPDATE order_items SET
            quantity = p_quantity,
            total_price = v_unit_price * p_quantity
        WHERE id = p_id;
        
        UPDATE orders SET total_price = (
            SELECT SUM(total_price) FROM order_items WHERE order_id = v_order_id
        ) WHERE id = v_order_id;
        
        SET p_success = TRUE;
        SET p_message = 'Tétel sikeresen módosítva';
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_order_items_delete$$
CREATE PROCEDURE sp_order_items_delete(
    IN p_id INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_order_id INT;
    DECLARE v_order_status VARCHAR(20);
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a tétel törlése során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    SELECT oi.order_id, o.status
    INTO v_order_id, v_order_status
    FROM order_items oi
    JOIN orders o ON o.id = oi.order_id
    WHERE oi.id = p_id;
    
    IF v_order_id IS NULL THEN
        SET p_success = FALSE;
        SET p_message = 'A tétel nem található';
    ELSEIF v_order_status != 'pending' THEN
        SET p_success = FALSE;
        SET p_message = 'Csak függőben lévő rendelés tétele törölhető';
    ELSE
        DELETE FROM order_items WHERE id = p_id;
        
        UPDATE orders SET total_price = IFNULL((
            SELECT SUM(total_price) FROM order_items WHERE order_id = v_order_id
        ), 0) WHERE id = v_order_id;
        
        SET p_success = TRUE;
        SET p_message = 'Tétel sikeresen törölve';
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_cart_create$$
CREATE PROCEDURE sp_cart_create(
    IN p_user_id INT,
    IN p_session_id VARCHAR(100),
    IN p_product_id INT,
    IN p_quantity INT,
    OUT p_new_id INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_existing_id INT;
    DECLARE v_available_keys INT;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a kosárhoz adás során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    IF NOT EXISTS (SELECT 1 FROM products WHERE id = p_product_id AND is_active = 1) THEN
        SET p_success = FALSE;
        SET p_message = 'A termék nem található vagy nem elérhető';
        SET p_new_id = NULL;
    ELSE
        SELECT COUNT(*) INTO v_available_keys FROM game_keys WHERE product_id = p_product_id AND is_sold = 0;
        
        IF v_available_keys < IFNULL(p_quantity, 1) THEN
            SET p_success = FALSE;
            SET p_message = CONCAT('Nincs elég készlet. Elérhető: ', v_available_keys);
            SET p_new_id = NULL;
        ELSE
            SELECT id INTO v_existing_id FROM cart 
            WHERE product_id = p_product_id 
              AND ((p_user_id IS NOT NULL AND user_id = p_user_id) 
                   OR (p_session_id IS NOT NULL AND session_id = p_session_id));
            
            IF v_existing_id IS NOT NULL THEN
                UPDATE cart SET quantity = quantity + IFNULL(p_quantity, 1), updated_at = CURRENT_TIMESTAMP
                WHERE id = v_existing_id;
                SET p_new_id = v_existing_id;
            ELSE
                INSERT INTO cart (user_id, session_id, product_id, quantity)
                VALUES (p_user_id, p_session_id, p_product_id, IFNULL(p_quantity, 1));
                SET p_new_id = LAST_INSERT_ID();
            END IF;
            
            SET p_success = TRUE;
            SET p_message = 'Termék hozzáadva a kosárhoz';
        END IF;
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_cart_get$$
CREATE PROCEDURE sp_cart_get(
    IN p_user_id INT,
    IN p_session_id VARCHAR(100)
)
BEGIN
    SELECT c.*, p.name, p.price, p.image_url, p.platform,
           (SELECT COUNT(*) FROM game_keys WHERE product_id = c.product_id AND is_sold = 0) as available_keys,
           (c.quantity * p.price) as line_total
    FROM cart c
    JOIN products p ON p.id = c.product_id
    WHERE (p_user_id IS NOT NULL AND c.user_id = p_user_id)
       OR (p_session_id IS NOT NULL AND c.session_id = p_session_id)
    ORDER BY c.created_at;
    
    SELECT SUM(c.quantity * p.price) as cart_total, SUM(c.quantity) as total_items
    FROM cart c
    JOIN products p ON p.id = c.product_id
    WHERE (p_user_id IS NOT NULL AND c.user_id = p_user_id)
       OR (p_session_id IS NOT NULL AND c.session_id = p_session_id);
END$$

DROP PROCEDURE IF EXISTS sp_cart_get_by_id$$
CREATE PROCEDURE sp_cart_get_by_id(IN p_id INT)
BEGIN
    SELECT c.*, p.name, p.price, p.image_url, p.platform
    FROM cart c
    JOIN products p ON p.id = c.product_id
    WHERE c.id = p_id;
END$$

DROP PROCEDURE IF EXISTS sp_cart_update$$
CREATE PROCEDURE sp_cart_update(
    IN p_id INT,
    IN p_quantity INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_product_id INT;
    DECLARE v_available_keys INT;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a kosár módosítása során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    SELECT product_id INTO v_product_id FROM cart WHERE id = p_id;
    
    IF v_product_id IS NULL THEN
        SET p_success = FALSE;
        SET p_message = 'A kosár elem nem található';
    ELSE
        SELECT COUNT(*) INTO v_available_keys FROM game_keys WHERE product_id = v_product_id AND is_sold = 0;
        
        IF p_quantity > v_available_keys THEN
            SET p_success = FALSE;
            SET p_message = CONCAT('Nincs elég készlet. Elérhető: ', v_available_keys);
        ELSEIF p_quantity <= 0 THEN
            DELETE FROM cart WHERE id = p_id;
            SET p_success = TRUE;
            SET p_message = 'Termék eltávolítva a kosárból';
        ELSE
            UPDATE cart SET quantity = p_quantity, updated_at = CURRENT_TIMESTAMP WHERE id = p_id;
            SET p_success = TRUE;
            SET p_message = 'Kosár sikeresen módosítva';
        END IF;
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_cart_delete$$
CREATE PROCEDURE sp_cart_delete(
    IN p_id INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a törlés során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    IF NOT EXISTS (SELECT 1 FROM cart WHERE id = p_id) THEN
        SET p_success = FALSE;
        SET p_message = 'A kosár elem nem található';
    ELSE
        DELETE FROM cart WHERE id = p_id;
        SET p_success = TRUE;
        SET p_message = 'Termék eltávolítva a kosárból';
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_cart_clear$$
CREATE PROCEDURE sp_cart_clear(
    IN p_user_id INT,
    IN p_session_id VARCHAR(100),
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    START TRANSACTION;
    
    DELETE FROM cart 
    WHERE (p_user_id IS NOT NULL AND user_id = p_user_id)
       OR (p_session_id IS NOT NULL AND session_id = p_session_id);
    
    SET p_success = TRUE;
    SET p_message = 'Kosár sikeresen ürítve';
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_favorites_create$$
CREATE PROCEDURE sp_favorites_create(
    IN p_user_id INT,
    IN p_product_id INT,
    OUT p_new_id INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a kedvencekhez adás során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    IF NOT EXISTS (SELECT 1 FROM users WHERE id = p_user_id AND is_active = 1) THEN
        SET p_success = FALSE;
        SET p_message = 'Érvénytelen felhasználó';
        SET p_new_id = NULL;
    ELSEIF NOT EXISTS (SELECT 1 FROM products WHERE id = p_product_id AND is_active = 1) THEN
        SET p_success = FALSE;
        SET p_message = 'A termék nem található';
        SET p_new_id = NULL;
    ELSEIF EXISTS (SELECT 1 FROM favorites WHERE user_id = p_user_id AND product_id = p_product_id) THEN
        SELECT id INTO p_new_id FROM favorites WHERE user_id = p_user_id AND product_id = p_product_id;
        SET p_success = TRUE;
        SET p_message = 'A termék már a kedvencek között van';
    ELSE
        INSERT INTO favorites (user_id, product_id) VALUES (p_user_id, p_product_id);
        SET p_new_id = LAST_INSERT_ID();
        SET p_success = TRUE;
        SET p_message = 'Termék hozzáadva a kedvencekhez';
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_favorites_get_by_user$$
CREATE PROCEDURE sp_favorites_get_by_user(
    IN p_user_id INT,
    IN p_page INT,
    IN p_page_size INT
)
BEGIN
    DECLARE v_offset INT;
    DECLARE v_limit INT;
    SET v_limit = IFNULL(p_page_size, 20);
    SET v_offset = (IFNULL(p_page, 1) - 1) * v_limit;
    
    SELECT f.id, f.created_at as added_at, p.*,
           (SELECT COUNT(*) FROM game_keys WHERE product_id = p.id AND is_sold = 0) as available_keys
    FROM favorites f
    JOIN products p ON p.id = f.product_id
    WHERE f.user_id = p_user_id AND p.is_active = 1
    ORDER BY f.created_at DESC
    LIMIT v_limit OFFSET v_offset;
    
    SELECT COUNT(*) as total_count
    FROM favorites f
    JOIN products p ON p.id = f.product_id
    WHERE f.user_id = p_user_id AND p.is_active = 1;
END$$

DROP PROCEDURE IF EXISTS sp_favorites_get_by_id$$
CREATE PROCEDURE sp_favorites_get_by_id(IN p_id INT)
BEGIN
    SELECT f.*, p.name, p.price, p.platform, p.image_url
    FROM favorites f
    JOIN products p ON p.id = f.product_id
    WHERE f.id = p_id;
END$$

DROP PROCEDURE IF EXISTS sp_favorites_check$$
CREATE PROCEDURE sp_favorites_check(
    IN p_user_id INT,
    IN p_product_id INT,
    OUT p_is_favorite BOOLEAN
)
BEGIN
    SET p_is_favorite = EXISTS (SELECT 1 FROM favorites WHERE user_id = p_user_id AND product_id = p_product_id);
END$$

DROP PROCEDURE IF EXISTS sp_favorites_delete$$
CREATE PROCEDURE sp_favorites_delete(
    IN p_id INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    IF NOT EXISTS (SELECT 1 FROM favorites WHERE id = p_id) THEN
        SET p_success = FALSE;
        SET p_message = 'A kedvenc nem található';
    ELSE
        DELETE FROM favorites WHERE id = p_id;
        SET p_success = TRUE;
        SET p_message = 'Termék eltávolítva a kedvencekből';
    END IF;
END$$

DROP PROCEDURE IF EXISTS sp_favorites_delete_by_user_product$$
CREATE PROCEDURE sp_favorites_delete_by_user_product(
    IN p_user_id INT,
    IN p_product_id INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    IF NOT EXISTS (SELECT 1 FROM favorites WHERE user_id = p_user_id AND product_id = p_product_id) THEN
        SET p_success = FALSE;
        SET p_message = 'A kedvenc nem található';
    ELSE
        DELETE FROM favorites WHERE user_id = p_user_id AND product_id = p_product_id;
        SET p_success = TRUE;
        SET p_message = 'Termék eltávolítva a kedvencekből';
    END IF;
END$$

DROP PROCEDURE IF EXISTS sp_coupons_create$$
CREATE PROCEDURE sp_coupons_create(
    IN p_code VARCHAR(50),
    IN p_discount_type ENUM('percent', 'fixed'),
    IN p_discount_value INT,
    IN p_min_order_value INT,
    IN p_max_uses INT,
    IN p_valid_from TIMESTAMP,
    IN p_valid_until TIMESTAMP,
    OUT p_new_id INT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a kupon létrehozása során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    IF EXISTS (SELECT 1 FROM coupons WHERE code = p_code) THEN
        SET p_success = FALSE;
        SET p_message = 'Ez a kuponkód már létezik';
        SET p_new_id = NULL;
    ELSEIF p_discount_type = 'percent' AND (p_discount_value < 1 OR p_discount_value > 100) THEN
        SET p_success = FALSE;
        SET p_message = 'Százalékos kedvezmény 1-100 között lehet';
        SET p_new_id = NULL;
    ELSE
        INSERT INTO coupons (code, discount_type, discount_value, min_order_value, max_uses, valid_from, valid_until, is_active)
        VALUES (UPPER(p_code), p_discount_type, p_discount_value, IFNULL(p_min_order_value, 0), 
                p_max_uses, p_valid_from, p_valid_until, 1);
        
        SET p_new_id = LAST_INSERT_ID();
        SET p_success = TRUE;
        SET p_message = 'Kupon sikeresen létrehozva';
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_coupons_get_by_id$$
CREATE PROCEDURE sp_coupons_get_by_id(IN p_id INT)
BEGIN
    SELECT *, 
           CASE WHEN NOW() BETWEEN valid_from AND valid_until AND is_active = 1 
                     AND (max_uses IS NULL OR used_count < max_uses) THEN 1 ELSE 0 END as is_currently_valid
    FROM coupons
    WHERE id = p_id;
END$$

DROP PROCEDURE IF EXISTS sp_coupons_get_by_code$$
CREATE PROCEDURE sp_coupons_get_by_code(IN p_code VARCHAR(50))
BEGIN
    SELECT *, 
           CASE WHEN NOW() BETWEEN valid_from AND valid_until AND is_active = 1 
                     AND (max_uses IS NULL OR used_count < max_uses) THEN 1 ELSE 0 END as is_currently_valid
    FROM coupons
    WHERE code = UPPER(p_code);
END$$

DROP PROCEDURE IF EXISTS sp_coupons_get_all$$
CREATE PROCEDURE sp_coupons_get_all(
    IN p_page INT,
    IN p_page_size INT,
    IN p_is_active TINYINT,
    IN p_show_expired BOOLEAN
)
BEGIN
    DECLARE v_offset INT;
    DECLARE v_limit INT;
    SET v_limit = IFNULL(p_page_size, 20);
    SET v_offset = (IFNULL(p_page, 1) - 1) * v_limit;
    
    SELECT *, 
           CASE WHEN NOW() BETWEEN valid_from AND valid_until AND is_active = 1 
                     AND (max_uses IS NULL OR used_count < max_uses) THEN 1 ELSE 0 END as is_currently_valid
    FROM coupons
    WHERE (p_is_active IS NULL OR is_active = p_is_active)
      AND (p_show_expired = TRUE OR valid_until >= NOW())
    ORDER BY created_at DESC
    LIMIT v_limit OFFSET v_offset;
    
    SELECT COUNT(*) as total_count FROM coupons
    WHERE (p_is_active IS NULL OR is_active = p_is_active)
      AND (p_show_expired = TRUE OR valid_until >= NOW());
END$$

DROP PROCEDURE IF EXISTS sp_coupons_update$$
CREATE PROCEDURE sp_coupons_update(
    IN p_id INT,
    IN p_code VARCHAR(50),
    IN p_discount_type ENUM('percent', 'fixed'),
    IN p_discount_value INT,
    IN p_min_order_value INT,
    IN p_max_uses INT,
    IN p_valid_from TIMESTAMP,
    IN p_valid_until TIMESTAMP,
    IN p_is_active TINYINT,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a kupon módosítása során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    IF NOT EXISTS (SELECT 1 FROM coupons WHERE id = p_id) THEN
        SET p_success = FALSE;
        SET p_message = 'A kupon nem található';
    ELSEIF p_code IS NOT NULL AND EXISTS (SELECT 1 FROM coupons WHERE code = UPPER(p_code) AND id != p_id) THEN
        SET p_success = FALSE;
        SET p_message = 'Ez a kuponkód már létezik';
    ELSE
        UPDATE coupons SET
            code = IFNULL(UPPER(p_code), code),
            discount_type = IFNULL(p_discount_type, discount_type),
            discount_value = IFNULL(p_discount_value, discount_value),
            min_order_value = IFNULL(p_min_order_value, min_order_value),
            max_uses = IFNULL(p_max_uses, max_uses),
            valid_from = IFNULL(p_valid_from, valid_from),
            valid_until = IFNULL(p_valid_until, valid_until),
            is_active = IFNULL(p_is_active, is_active)
        WHERE id = p_id;
        
        SET p_success = TRUE;
        SET p_message = 'Kupon sikeresen módosítva';
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_coupons_delete$$
CREATE PROCEDURE sp_coupons_delete(
    IN p_id INT,
    IN p_hard_delete BOOLEAN,
    OUT p_success BOOLEAN,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_success = FALSE;
        SET p_message = 'Hiba történt a kupon törlése során';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    IF NOT EXISTS (SELECT 1 FROM coupons WHERE id = p_id) THEN
        SET p_success = FALSE;
        SET p_message = 'A kupon nem található';
    ELSEIF p_hard_delete = TRUE THEN
        DELETE FROM coupons WHERE id = p_id;
        SET p_success = TRUE;
        SET p_message = 'Kupon véglegesen törölve';
    ELSE
        UPDATE coupons SET is_active = 0 WHERE id = p_id;
        SET p_success = TRUE;
        SET p_message = 'Kupon inaktiválva';
    END IF;
    
    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_audit_log_create$$
CREATE PROCEDURE sp_audit_log_create(
    IN p_table_name VARCHAR(50),
    IN p_record_id INT,
    IN p_action ENUM('INSERT', 'UPDATE', 'DELETE'),
    IN p_old_values JSON,
    IN p_new_values JSON,
    IN p_user_id INT,
    IN p_ip_address VARCHAR(45),
    OUT p_new_id INT
)
BEGIN
    INSERT INTO audit_log (table_name, record_id, action, old_values, new_values, user_id, ip_address)
    VALUES (p_table_name, p_record_id, p_action, p_old_values, p_new_values, p_user_id, p_ip_address);
    
    SET p_new_id = LAST_INSERT_ID();
END$$

DROP PROCEDURE IF EXISTS sp_audit_log_get_by_id$$
CREATE PROCEDURE sp_audit_log_get_by_id(IN p_id INT)
BEGIN
    SELECT al.*, u.username
    FROM audit_log al
    LEFT JOIN users u ON u.id = al.user_id
    WHERE al.id = p_id;
END$$

DROP PROCEDURE IF EXISTS sp_audit_log_get_all$$
CREATE PROCEDURE sp_audit_log_get_all(
    IN p_page INT,
    IN p_page_size INT,
    IN p_table_name VARCHAR(50),
    IN p_action ENUM('INSERT', 'UPDATE', 'DELETE'),
    IN p_record_id INT,
    IN p_user_id INT,
    IN p_date_from DATETIME,
    IN p_date_to DATETIME
)
BEGIN
    DECLARE v_offset INT;
    DECLARE v_limit INT;
    SET v_limit = IFNULL(p_page_size, 50);
    SET v_offset = (IFNULL(p_page, 1) - 1) * v_limit;
    
    SELECT al.*, u.username
    FROM audit_log al
    LEFT JOIN users u ON u.id = al.user_id
    WHERE (p_table_name IS NULL OR al.table_name = p_table_name)
      AND (p_action IS NULL OR al.action = p_action)
      AND (p_record_id IS NULL OR al.record_id = p_record_id)
      AND (p_user_id IS NULL OR al.user_id = p_user_id)
      AND (p_date_from IS NULL OR al.created_at >= p_date_from)
      AND (p_date_to IS NULL OR al.created_at <= p_date_to)
    ORDER BY al.created_at DESC
    LIMIT v_limit OFFSET v_offset;
    
    SELECT COUNT(*) as total_count
    FROM audit_log al
    WHERE (p_table_name IS NULL OR al.table_name = p_table_name)
      AND (p_action IS NULL OR al.action = p_action)
      AND (p_record_id IS NULL OR al.record_id = p_record_id)
      AND (p_user_id IS NULL OR al.user_id = p_user_id)
      AND (p_date_from IS NULL OR al.created_at >= p_date_from)
      AND (p_date_to IS NULL OR al.created_at <= p_date_to);
END$$

DROP PROCEDURE IF EXISTS sp_audit_log_get_by_record$$
CREATE PROCEDURE sp_audit_log_get_by_record(
    IN p_table_name VARCHAR(50),
    IN p_record_id INT
)
BEGIN
    SELECT al.*, u.username
    FROM audit_log al
    LEFT JOIN users u ON u.id = al.user_id
    WHERE al.table_name = p_table_name AND al.record_id = p_record_id
    ORDER BY al.created_at DESC;
END$$

DROP PROCEDURE IF EXISTS sp_audit_log_delete_old$$
CREATE PROCEDURE sp_audit_log_delete_old(
    IN p_days_to_keep INT,
    OUT p_deleted_count INT
)
BEGIN
    DELETE FROM audit_log WHERE created_at < DATE_SUB(NOW(), INTERVAL p_days_to_keep DAY);
    SET p_deleted_count = ROW_COUNT();
END$$

DROP PROCEDURE IF EXISTS sp_audit_log_get_stats$$
CREATE PROCEDURE sp_audit_log_get_stats(
    IN p_date_from DATE,
    IN p_date_to DATE
)
BEGIN
    SELECT 
        table_name,
        action,
        COUNT(*) as count
    FROM audit_log
    WHERE (p_date_from IS NULL OR DATE(created_at) >= p_date_from)
      AND (p_date_to IS NULL OR DATE(created_at) <= p_date_to)
    GROUP BY table_name, action
    ORDER BY table_name, action;
END$$

DELIMITER ;

DELIMITER $$

DROP TRIGGER IF EXISTS tr_before_order_insert$$
CREATE TRIGGER tr_before_order_insert
BEFORE INSERT ON orders
FOR EACH ROW
BEGIN
    IF NEW.order_number IS NULL THEN
        SET NEW.order_number = fn_generate_order_number();
    END IF;
END$$

DROP TRIGGER IF EXISTS tr_users_audit_update$$
CREATE TRIGGER tr_users_audit_update
AFTER UPDATE ON users
FOR EACH ROW
BEGIN
    INSERT INTO audit_log (table_name, record_id, action, old_values, new_values)
    VALUES ('users', OLD.id, 'UPDATE', 
            JSON_OBJECT('username', OLD.username, 'email', OLD.email, 'role', OLD.role, 'is_active', OLD.is_active),
            JSON_OBJECT('username', NEW.username, 'email', NEW.email, 'role', NEW.role, 'is_active', NEW.is_active));
END$$

DROP TRIGGER IF EXISTS tr_orders_audit_update$$
CREATE TRIGGER tr_orders_audit_update
AFTER UPDATE ON orders
FOR EACH ROW
BEGIN
    IF OLD.status != NEW.status THEN
        INSERT INTO audit_log (table_name, record_id, action, old_values, new_values)
        VALUES ('orders', OLD.id, 'UPDATE',
                JSON_OBJECT('status', OLD.status),
                JSON_OBJECT('status', NEW.status));
    END IF;
END$$

DELIMITER ;

SET GLOBAL event_scheduler = ON;

DELIMITER $$

DROP EVENT IF EXISTS ev_clean_old_carts$$
CREATE EVENT ev_clean_old_carts
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP
DO
BEGIN
    DELETE FROM cart WHERE user_id IS NULL AND created_at < DATE_SUB(NOW(), INTERVAL 7 DAY);
END$$

DROP EVENT IF EXISTS ev_unlock_users$$
CREATE EVENT ev_unlock_users
ON SCHEDULE EVERY 5 MINUTE
DO
BEGIN
    UPDATE users SET locked_until = NULL, failed_login_attempts = 0 
    WHERE locked_until IS NOT NULL AND locked_until <= NOW();
END$$

DELIMITER ;

INSERT INTO users (username, email, password_hash, full_name, role, is_active) VALUES
('admin', 'admin@gamecube.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZRGdjGj/n3.hfwwXJJUBMNHMB3NwW', 'Rendszergazda', 'admin', 1);

INSERT INTO users (username, email, password_hash, full_name, phone, role, is_active) VALUES
('testuser', 'test@example.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZRGdjGj/n3.hfwwXJJUBMNHMB3NwW', 'Teszt Felhasználó', '+36301234567', 'user', 1);

INSERT INTO products (name, short_description, long_description, platform, tag, price, original_price, discount_percent, image_url, is_active) VALUES
('Cyberpunk 2077', 'Nyílt világú akció RPG futurisztikus Night City-ben', 'A Cyberpunk 2077 egy nyílt világú akció-kalandjáték, amely a sötét jövő Night City nevű megalopoliszában játszódik.', 'pc', 'top', 8990, 14990, 40, 'cyberpunk2077.png', 1),
('Elden Ring', 'Epikus fantasy akció RPG a Dark Souls alkotóitól', 'A FromSoftware és George R.R. Martin közös alkotása, egy hatalmas fantasy világban.', 'pc', 'top', 12990, NULL, 0, 'eldenring.png', 1),
('EA Sports FC 25', 'A legújabb EA Sports futball szimulátor', 'Az EA Sports FC 25 a világ legnépszerűbb futballszimulátorának legújabb része.', 'pc', 'new', 15490, NULL, 0, 'fc25.png', 1),
('GTA V Premium Edition', 'Grand Theft Auto V teljes kiadás', 'A GTA V Premium Edition tartalmazza a teljes Grand Theft Auto V játékot és a GTA Online-t.', 'xbox', 'sale', 4990, 9990, 50, 'gta5.png', 1),
('The Witcher 3: Wild Hunt', 'Legendás fantasy RPG Geralt kalandjaival', 'A The Witcher 3: Wild Hunt egy történetvezérelt, nyílt világú RPG.', 'pc', 'sale', 2990, 7990, 63, 'thewitcher3.png', 1),
('Minecraft Java & Bedrock', 'A világ legnépszerűbb sandbox játéka', 'A Minecraft egy sandbox videojáték, amelyben gyakorlatilag bármit építhetsz.', 'pc', 'top', 7490, NULL, 0, 'minecraft.png', 1),
('Red Dead Redemption 2', 'Epikus western kaland a Vadnyugaton', 'Az Arthur Morgan és a Van der Linde banda történetét mesélő epikus western.', 'ps', 'normal', 9990, 14990, 33, 'rdr2.png', 1),
('God of War Ragnarök', 'Kratos és Atreus északi kalandja', 'A God of War folytatása, Kratos és Atreus Ragnarök előtti kalandja.', 'ps', 'top', 16990, NULL, 0, 'godofwar.png', 1),
('Hogwarts Legacy', 'Varázslatos kaland a Roxfort világában', 'Nyílt világú akció RPG a Harry Potter univerzumban.', 'pc', 'new', 13990, NULL, 0, 'hogwarts.png', 1),
('Steam Wallet 10€', 'Steam egyenleg feltöltés', 'Steam egyenleg feltöltés 10 euró értékben.', 'pc', 'normal', 4490, NULL, 0, 'steam.png', 1);

INSERT INTO game_keys (product_id, key_code, is_sold) VALUES
(1, 'CYBER-2077-XXXX-YYYY-ZZZZ', 0), (1, 'CYBER-2077-AAAA-BBBB-CCCC', 0), (1, 'CYBER-2077-DDDD-EEEE-FFFF', 0),
(2, 'ELDEN-RING-XXXX-YYYY-ZZZZ', 0), (2, 'ELDEN-RING-AAAA-BBBB-CCCC', 0), (2, 'ELDEN-RING-DDDD-EEEE-FFFF', 0),
(3, 'FC25-XXXX-YYYY-ZZZZ-AAAA', 0), (3, 'FC25-BBBB-CCCC-DDDD-EEEE', 0),
(4, 'GTA5X-XXXX-YYYY-ZZZZ-AAAA', 0), (4, 'GTA5X-BBBB-CCCC-DDDD-EEEE', 0), (4, 'GTA5X-FFFF-GGGG-HHHH-IIII', 0),
(5, 'W3WH-XXXX-YYYY-ZZZZ-AAAA', 0), (5, 'W3WH-BBBB-CCCC-DDDD-EEEE', 0), (5, 'W3WH-FFFF-GGGG-HHHH-IIII', 0),
(6, 'MC-JAVA-XXXX-YYYY-ZZZZ', 0), (6, 'MC-JAVA-AAAA-BBBB-CCCC', 0),
(7, 'RDR2-XXXX-YYYY-ZZZZ-AAAA', 0), (7, 'RDR2-BBBB-CCCC-DDDD-EEEE', 0),
(8, 'GOW-XXXX-YYYY-ZZZZ-AAAA', 0), (8, 'GOW-BBBB-CCCC-DDDD-EEEE', 0),
(9, 'HOGW-XXXX-YYYY-ZZZZ-AAAA', 0), (9, 'HOGW-BBBB-CCCC-DDDD-EEEE', 0), (9, 'HOGW-FFFF-GGGG-HHHH-IIII', 0),
(10, 'STEAM-10E-XXXX-YYYY-ZZZ', 0), (10, 'STEAM-10E-AAAA-BBBB-CCC', 0), (10, 'STEAM-10E-DDDD-EEEE-FFF', 0);

INSERT INTO products (name, short_description, platform, tag, price, image_url, is_active) VALUES
('Cyberpunk 2077 PC', 'Futuristic RPG', 'pc', 'normal', 8990, 'cyberpunk2077_pc.png', 1),
('Elden Ring PS', 'Open world fantasy', 'ps', 'normal', 12990, 'eldenring_ps.png', 1),
('EA Sports FC 25 Xbox', 'Football game', 'xbox', 'normal', 15490, 'fc25_xbox.png', 1),
('GTA V Premium Edition Xbox', 'Action adventure', 'xbox', 'normal', 4990, 'gta5_xbox2.png', 1),
('The Witcher 3: Wild Hunt PC', 'Fantasy RPG', 'pc', 'normal', 5990, 'witcher3_pc.png', 1),
('Minecraft Java & Bedrock PC', 'Sandbox building', 'pc', 'normal', 7990, 'minecraft_pc.png', 1),
('Valorant Points 4750', 'FPS points pack', 'pc', 'normal', 12990, 'valorant_points.png', 1),
('Steam Wallet 10€ PC', 'Digital currency', 'pc', 'normal', 3900, 'steam_wallet.png', 1),
('FIFA 25', 'Football simulation', 'ps', 'normal', 15990, 'fifa25.png', 1),
('Assassin\'s Creed Valhalla', 'Viking adventure', 'ps', 'normal', 13990, 'acvalhalla.png', 1),
('Forza Horizon 6', 'Racing open world', 'xbox', 'normal', 14990, 'forza6.png', 1),
('Halo Infinite', 'FPS shooter', 'xbox', 'normal', 12990, 'halo_infinite.png', 1),
('Resident Evil Village', 'Horror survival', 'ps', 'normal', 12990, 're_village.png', 1),
('God of War Ragnarok PS', 'Action adventure', 'ps', 'normal', 16990, 'gow_ragnarok.png', 1),
('Red Dead Redemption 2 Xbox', 'Western epic', 'xbox', 'normal', 15990, 'rdr2_xbox.png', 1),
('CyberConnect RPG', 'Story-driven RPG', 'pc', 'normal', 10990, 'cyberconnect.png', 1),
('Overwatch 2', 'Team shooter', 'pc', 'normal', 14990, 'overwatch2.png', 1),
('Call of Duty Modern Warfare II', 'FPS action', 'ps', 'normal', 18990, 'cod_mw2.png', 1),
('The Sims 4', 'Life simulation', 'pc', 'normal', 7990, 'sims4.png', 1),
('F1 24', 'Racing simulation', 'xbox', 'normal', 12990, 'f124.png', 1),
('Monster Hunter Rise', 'Action RPG', 'switch', 'normal', 14990, 'mh_rise.png', 1),
('Splatoon 3', 'Shooter multiplayer', 'switch', 'normal', 12990, 'splatoon3.png', 1),
('Mario Kart 9', 'Racing fun', 'switch', 'normal', 15990, 'mariokart9.png', 1),
('Zelda: Tears of the Kingdom', 'Adventure epic', 'switch', 'normal', 17990, 'zelda_totk.png', 1),
('Pokémon Scarlet & Violet', 'RPG adventure', 'switch', 'normal', 13990, 'pokemon_sv.png', 1),
('Star Wars Jedi: Survivor', 'Action adventure', 'ps', 'normal', 14990, 'jedi_survivor.png', 1),
('Horizon Forbidden West', 'Open world adventure', 'ps', 'normal', 16990, 'horizon_fw.png', 1),
('Diablo IV', 'Dark action RPG', 'pc', 'normal', 15990, 'diablo4.png', 1),
('Stardew Valley', 'Farming sim', 'pc', 'normal', 5990, 'stardew.png', 1);

INSERT INTO game_keys (product_id, key_code, is_sold) VALUES
(11, 'CP77PC-XXXX-YYYY-ZZZZ-0001', 0), (11, 'CP77PC-XXXX-YYYY-ZZZZ-0002', 0), (11, 'CP77PC-XXXX-YYYY-ZZZZ-0003', 0),
(12, 'ELDENPS-XXX-YYYY-ZZZZ-0001', 0), (12, 'ELDENPS-XXX-YYYY-ZZZZ-0002', 0), (12, 'ELDENPS-XXX-YYYY-ZZZZ-0003', 0),
(13, 'FC25XB-XXXX-YYYY-ZZZZ-0001', 0), (13, 'FC25XB-XXXX-YYYY-ZZZZ-0002', 0), (13, 'FC25XB-XXXX-YYYY-ZZZZ-0003', 0),
(14, 'GTA5XB-XXXX-YYYY-ZZZZ-0001', 0), (14, 'GTA5XB-XXXX-YYYY-ZZZZ-0002', 0), (14, 'GTA5XB-XXXX-YYYY-ZZZZ-0003', 0),
(15, 'W3WHPC-XXXX-YYYY-ZZZZ-0001', 0), (15, 'W3WHPC-XXXX-YYYY-ZZZZ-0002', 0), (15, 'W3WHPC-XXXX-YYYY-ZZZZ-0003', 0),
(16, 'MCJBPC-XXXX-YYYY-ZZZZ-0001', 0), (16, 'MCJBPC-XXXX-YYYY-ZZZZ-0002', 0), (16, 'MCJBPC-XXXX-YYYY-ZZZZ-0003', 0),
(17, 'VALPTS-XXXX-YYYY-ZZZZ-0001', 0), (17, 'VALPTS-XXXX-YYYY-ZZZZ-0002', 0), (17, 'VALPTS-XXXX-YYYY-ZZZZ-0003', 0),
(18, 'STM10E-XXXX-YYYY-ZZZZ-0001', 0), (18, 'STM10E-XXXX-YYYY-ZZZZ-0002', 0), (18, 'STM10E-XXXX-YYYY-ZZZZ-0003', 0),
(19, 'FIFA25-XXXX-YYYY-ZZZZ-0001', 0), (19, 'FIFA25-XXXX-YYYY-ZZZZ-0002', 0), (19, 'FIFA25-XXXX-YYYY-ZZZZ-0003', 0),
(20, 'ACVALH-XXXX-YYYY-ZZZZ-0001', 0), (20, 'ACVALH-XXXX-YYYY-ZZZZ-0002', 0), (20, 'ACVALH-XXXX-YYYY-ZZZZ-0003', 0),
(21, 'FRZH6X-XXXX-YYYY-ZZZZ-0001', 0), (21, 'FRZH6X-XXXX-YYYY-ZZZZ-0002', 0), (21, 'FRZH6X-XXXX-YYYY-ZZZZ-0003', 0),
(22, 'HALOIF-XXXX-YYYY-ZZZZ-0001', 0), (22, 'HALOIF-XXXX-YYYY-ZZZZ-0002', 0), (22, 'HALOIF-XXXX-YYYY-ZZZZ-0003', 0),
(23, 'REVILL-XXXX-YYYY-ZZZZ-0001', 0), (23, 'REVILL-XXXX-YYYY-ZZZZ-0002', 0), (23, 'REVILL-XXXX-YYYY-ZZZZ-0003', 0),
(24, 'GOWRAG-XXXX-YYYY-ZZZZ-0001', 0), (24, 'GOWRAG-XXXX-YYYY-ZZZZ-0002', 0), (24, 'GOWRAG-XXXX-YYYY-ZZZZ-0003', 0),
(25, 'RDR2XB-XXXX-YYYY-ZZZZ-0001', 0), (25, 'RDR2XB-XXXX-YYYY-ZZZZ-0002', 0), (25, 'RDR2XB-XXXX-YYYY-ZZZZ-0003', 0),
(26, 'CYBCON-XXXX-YYYY-ZZZZ-0001', 0), (26, 'CYBCON-XXXX-YYYY-ZZZZ-0002', 0), (26, 'CYBCON-XXXX-YYYY-ZZZZ-0003', 0),
(27, 'OW2PC0-XXXX-YYYY-ZZZZ-0001', 0), (27, 'OW2PC0-XXXX-YYYY-ZZZZ-0002', 0), (27, 'OW2PC0-XXXX-YYYY-ZZZZ-0003', 0),
(28, 'CODMW2-XXXX-YYYY-ZZZZ-0001', 0), (28, 'CODMW2-XXXX-YYYY-ZZZZ-0002', 0), (28, 'CODMW2-XXXX-YYYY-ZZZZ-0003', 0),
(29, 'SIMS4P-XXXX-YYYY-ZZZZ-0001', 0), (29, 'SIMS4P-XXXX-YYYY-ZZZZ-0002', 0), (29, 'SIMS4P-XXXX-YYYY-ZZZZ-0003', 0),
(30, 'F124XB-XXXX-YYYY-ZZZZ-0001', 0), (30, 'F124XB-XXXX-YYYY-ZZZZ-0002', 0), (30, 'F124XB-XXXX-YYYY-ZZZZ-0003', 0),
(31, 'MHRISE-XXXX-YYYY-ZZZZ-0001', 0), (31, 'MHRISE-XXXX-YYYY-ZZZZ-0002', 0), (31, 'MHRISE-XXXX-YYYY-ZZZZ-0003', 0),
(32, 'SPLAT3-XXXX-YYYY-ZZZZ-0001', 0), (32, 'SPLAT3-XXXX-YYYY-ZZZZ-0002', 0), (32, 'SPLAT3-XXXX-YYYY-ZZZZ-0003', 0),
(33, 'MK9NSW-XXXX-YYYY-ZZZZ-0001', 0), (33, 'MK9NSW-XXXX-YYYY-ZZZZ-0002', 0), (33, 'MK9NSW-XXXX-YYYY-ZZZZ-0003', 0),
(34, 'ZELDTK-XXXX-YYYY-ZZZZ-0001', 0), (34, 'ZELDTK-XXXX-YYYY-ZZZZ-0002', 0), (34, 'ZELDTK-XXXX-YYYY-ZZZZ-0003', 0),
(35, 'PKMNSC-XXXX-YYYY-ZZZZ-0001', 0), (35, 'PKMNSC-XXXX-YYYY-ZZZZ-0002', 0), (35, 'PKMNSC-XXXX-YYYY-ZZZZ-0003', 0),
(36, 'SWJEDI-XXXX-YYYY-ZZZZ-0001', 0), (36, 'SWJEDI-XXXX-YYYY-ZZZZ-0002', 0), (36, 'SWJEDI-XXXX-YYYY-ZZZZ-0003', 0),
(37, 'HRZFW0-XXXX-YYYY-ZZZZ-0001', 0), (37, 'HRZFW0-XXXX-YYYY-ZZZZ-0002', 0), (37, 'HRZFW0-XXXX-YYYY-ZZZZ-0003', 0),
(38, 'DIAB4P-XXXX-YYYY-ZZZZ-0001', 0), (38, 'DIAB4P-XXXX-YYYY-ZZZZ-0002', 0), (38, 'DIAB4P-XXXX-YYYY-ZZZZ-0003', 0),
(39, 'STRDEW-XXXX-YYYY-ZZZZ-0001', 0), (39, 'STRDEW-XXXX-YYYY-ZZZZ-0002', 0), (39, 'STRDEW-XXXX-YYYY-ZZZZ-0003', 0);

INSERT INTO coupons (code, discount_type, discount_value, min_order_value, max_uses, valid_from, valid_until, is_active) VALUES
('WELCOME10', 'percent', 10, 5000, 100, NOW(), DATE_ADD(NOW(), INTERVAL 1 YEAR), 1),
('SUMMER2024', 'percent', 15, 10000, 50, NOW(), DATE_ADD(NOW(), INTERVAL 3 MONTH), 1),
('FLAT1000', 'fixed', 1000, 8000, NULL, NOW(), DATE_ADD(NOW(), INTERVAL 6 MONTH), 1);

OPTIMIZE TABLE users, products, game_keys, orders, order_items, cart, favorites, coupons, audit_log;

SELECT 
    ROUTINE_NAME as 'Eljárás/Függvény neve',
    ROUTINE_TYPE as 'Típus',
    CREATED as 'Létrehozva'
FROM information_schema.ROUTINES
WHERE ROUTINE_SCHEMA = 'gamecube'
ORDER BY ROUTINE_TYPE, ROUTINE_NAME;

-- =============================================
-- KAPCSOLAT ÜZENETEK TÁBLA
-- =============================================
CREATE TABLE IF NOT EXISTS contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
