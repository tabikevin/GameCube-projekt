<?php
header("Content-Type: text/html; charset=utf-8");
echo "<h1>GameCube Diagnosztika</h1>";
echo "<style>body{font-family:monospace;background:#1a1a2e;color:#eee;padding:20px} .ok{color:#4ade80} .err{color:#f87171} .warn{color:#fbbf24}</style>";

// 1. PHP verzió
echo "<h2>1. PHP</h2>";
echo "<p class='ok'>PHP verzió: " . phpversion() . "</p>";

// 2. Session
echo "<h2>2. Session</h2>";
session_start();
$_SESSION['test'] = 'ok';
if ($_SESSION['test'] === 'ok') {
    echo "<p class='ok'>✅ Session működik (ID: " . session_id() . ")</p>";
    echo "<p>Session user_id: " . ($_SESSION['user_id'] ?? 'NINCS') . "</p>";
    echo "<p>Session user_role: " . ($_SESSION['user_role'] ?? 'NINCS') . "</p>";
    echo "<p>Session cart: " . (isset($_SESSION['cart']) ? count($_SESSION['cart']) . " tétel" : 'NINCS/ÜRES') . "</p>";
} else {
    echo "<p class='err'>❌ Session NEM működik!</p>";
}

// 3. Adatbázis
echo "<h2>3. Adatbázis</h2>";
try {
    require_once "../config/db.php";
    echo "<p class='ok'>✅ MySQLi kapcsolat OK</p>";
    
    // Products
    $result = $conn->query("SELECT COUNT(*) as cnt FROM products WHERE is_active = 1");
    $row = $result->fetch_assoc();
    echo "<p class='ok'>✅ Aktív termékek: " . $row['cnt'] . " db</p>";
    
    // Users
    $result = $conn->query("SELECT COUNT(*) as cnt FROM users");
    $row = $result->fetch_assoc();
    echo "<p class='ok'>✅ Felhasználók: " . $row['cnt'] . " db</p>";
    
    // Orders table
    $result = $conn->query("SHOW COLUMNS FROM orders");
    if ($result) {
        echo "<p class='ok'>✅ orders tábla létezik</p>";
        $cols = [];
        while ($r = $result->fetch_assoc()) $cols[] = $r['Field'];
        echo "<p>Oszlopok: " . implode(', ', $cols) . "</p>";
    }
    
    // Order items table
    $result = $conn->query("SHOW COLUMNS FROM order_items");
    if ($result) {
        echo "<p class='ok'>✅ order_items tábla létezik</p>";
        $cols = [];
        while ($r = $result->fetch_assoc()) $cols[] = $r['Field'];
        echo "<p>Oszlopok: " . implode(', ', $cols) . "</p>";
        
        if (in_array('unit_price', $cols)) {
            echo "<p class='ok'>✅ unit_price oszlop OK</p>";
        } else {
            echo "<p class='err'>❌ unit_price oszlop HIÁNYZIK! (checkout nem fog működni)</p>";
        }
        if (in_array('total_price', $cols)) {
            echo "<p class='ok'>✅ total_price oszlop OK</p>";
        } else {
            echo "<p class='err'>❌ total_price oszlop HIÁNYZIK!</p>";
        }
        if (in_array('price', $cols)) {
            echo "<p class='warn'>⚠️ price oszlop létezik (régi séma)</p>";
        }
    } else {
        echo "<p class='err'>❌ order_items tábla NEM létezik!</p>";
    }
    
    // Game keys
    $result = $conn->query("SELECT COUNT(*) as cnt FROM game_keys WHERE is_sold = 0");
    if ($result) {
        $row = $result->fetch_assoc();
        echo "<p class='ok'>✅ Elérhető kulcsok: " . $row['cnt'] . " db</p>";
    }
    
    // Orders
    $result = $conn->query("SELECT COUNT(*) as cnt FROM orders");
    if ($result) {
        $row = $result->fetch_assoc();
        echo "<p>Rendelések eddig: " . $row['cnt'] . " db</p>";
    }

    // PDO
    echo "<p class='ok'>✅ PDO kapcsolat OK</p>";
    
} catch (Exception $e) {
    echo "<p class='err'>❌ Adatbázis hiba: " . $e->getMessage() . "</p>";
}

// 4. Fájlok
echo "<h2>4. Fájlok</h2>";
$files = [
    '../api/products.php',
    '../api/login.php',
    '../api/checkout.php',
    '../api/cart.php',
    '../api/profile.php',
    '../api/admin/orders.php',
    '../api/.htaccess',
    '../config/db.php',
    '../config/jwt_helper.php',
];
foreach ($files as $f) {
    if (file_exists($f)) {
        echo "<p class='ok'>✅ $f</p>";
    } else {
        echo "<p class='err'>❌ $f HIÁNYZIK!</p>";
    }
}

// 5. Auth.js tartalom ellenőrzés
echo "<h2>5. auth.js ellenőrzés</h2>";
$authjs = file_get_contents("assets/js/auth.js");
if ($authjs) {
    if (strpos($authjs, "pathParts") !== false) {
        echo "<p class='ok'>✅ auth.js DINAMIKUS API_BASE (helyes!)</p>";
    } else if (strpos($authjs, "'/gamecube/api'") !== false) {
        echo "<p class='err'>❌ auth.js HARDCODED '/gamecube/api' - RÉGI VERZIÓ!</p>";
    } else {
        echo "<p class='warn'>⚠️ auth.js ismeretlen verzió</p>";
    }
    echo "<p>Első 100 karakter: <code>" . htmlspecialchars(substr($authjs, 0, 100)) . "</code></p>";
} else {
    echo "<p class='err'>❌ auth.js nem olvasható!</p>";
}

// 6. Products API teszt
echo "<h2>6. Products API közvetlen teszt</h2>";
try {
    $result = $conn->query("SELECT id, name, price, platform FROM products WHERE is_active = 1 LIMIT 3");
    while ($row = $result->fetch_assoc()) {
        echo "<p class='ok'>  #{$row['id']} {$row['name']} - {$row['price']} Ft ({$row['platform']})</p>";
    }
} catch (Exception $e) {
    echo "<p class='err'>❌ " . $e->getMessage() . "</p>";
}

echo "<hr><p>Teszt vége: " . date('Y-m-d H:i:s') . "</p>";
