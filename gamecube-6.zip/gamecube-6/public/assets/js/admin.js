document.addEventListener('DOMContentLoaded', async () => {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    
    if (token && user) {
        try {
            const parsed = JSON.parse(user);
            if (parsed.role === 'admin') {
                loadOrders();
                return;
            }
        } catch {}
    }
    try {
        const res = await fetch('/gamecube/api/admin/admin-check.php');
        const data = await res.json();
        if (data.admin) {
            loadOrders();
            return;
        }
    } catch {}

    window.location.href = 'admin-login.html';
});

async function loadOrders() {
    try {
        const data = await apiRequest('admin/orders.php');

        if (data.success) {
            displayOrders(data.orders);
        }
    } catch (error) {
        alert('Hiba történt a rendelések betöltése során');
    }
}

function displayOrders(orders) {
    const tbody = document.getElementById('ordersBody');
    if (!tbody) return;

    if (orders.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center">Nincs rendelés</td></tr>';
        return;
    }

    tbody.innerHTML = orders.map(order => `
        <tr>
            <td>#${order.id}</td>
            <td>${formatDate(order.created_at)}</td>
            <td>${escapeHtml(order.username)}</td>
            <td>${formatPrice(order.total_price)} Ft</td>
            <td>${getPaymentMethodLabel(order.payment_method)}</td>
            <td><span class="badge ${getStatusBadgeClass(order.status)}">${getStatusLabel(order.status)}</span></td>
            <td>
                ${order.status === 'pending' ? `
                    <button class="btn btn-sm btn-success" onclick="approveOrder(${order.id})">
                        <i class="bi bi-check-circle"></i> Jóváhagyás
                    </button>
                ` : '<span class="text-light-50">-</span>'}
            </td>
        </tr>
    `).join('');
}

async function approveOrder(orderId) {
    if (!confirm('Biztosan jóváhagyod ezt a rendelést? A kulcsok automatikusan kiosztásra kerülnek.')) {
        return;
    }

    try {
        const data = await apiRequest('admin/orders.php', {
            method: 'POST',
            body: JSON.stringify({ order_id: orderId })
        });

        if (data.success) {
            alert(data.message);
            loadOrders();
        }
    } catch (error) {
        alert(error.message || 'Hiba történt a rendelés jóváhagyása során');
    }
}

function filterOrders() {
    const statusFilter = document.getElementById('statusFilter');
    const paymentFilter = document.getElementById('paymentFilter');
    
    if (!statusFilter || !paymentFilter) return;

    const rows = document.querySelectorAll('#ordersBody tr');
    const status = statusFilter.value;
    const payment = paymentFilter.value;

    rows.forEach(row => {
        const statusCell = row.querySelector('td:nth-child(6)');
        const paymentCell = row.querySelector('td:nth-child(5)');
        
        if (!statusCell || !paymentCell) return;

        const statusMatch = status === 'all' || statusCell.textContent.toLowerCase().includes(getStatusLabel(status).toLowerCase());
        const paymentMatch = payment === 'all' || paymentCell.textContent.includes(getPaymentMethodLabel(payment));

        row.style.display = (statusMatch && paymentMatch) ? '' : 'none';
    });
}

document.getElementById('statusFilter')?.addEventListener('change', filterOrders);
document.getElementById('paymentFilter')?.addEventListener('change', filterOrders);

function getStatusLabel(status) {
    const labels = {
        'pending': 'Függőben',
        'paid': 'Fizetve',
        'cancelled': 'Törölve'
    };
    return labels[status] || status;
}

function getStatusBadgeClass(status) {
    const classes = {
        'pending': 'bg-warning text-dark',
        'paid': 'bg-success',
        'cancelled': 'bg-danger'
    };
    return classes[status] || 'bg-secondary';
}

function getPaymentMethodLabel(method) {
    const labels = {
        'online_card': 'Online kártya',
        'bank_transfer': 'Banki átutalás',
        'paypal': 'PayPal'
    };
    return labels[method] || method;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('hu-HU', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function formatPrice(price) {
    return new Intl.NumberFormat('hu-HU').format(price);
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}